"""Pydantic models for Omnibenchmark."""

import os
import re
import sys
import warnings
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import yaml
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)
from pydantic import (
    ValidationError as PydanticValidationError,
)

from omnibenchmark.model._merge import merge_dict_list

from ._parsing import convert_pydantic_error_to_parse_error
from .params import Params
from .validation import BenchmarkParseError, BenchmarkValidator, ValidationError


class LineNumberLoader(yaml.SafeLoader):
    """Custom YAML loader that tracks line numbers for better error reporting."""

    def compose_node(self, parent, index):
        # Get the line number where the node starts
        line = self.line + 1  # YAML lines are 0-indexed, we need 1-indexed for the user
        node = super().compose_node(parent, index)
        # I use setattr to avoid type checker errors with dynamic attributes (__line__ is our custom attribute)
        setattr(node, "__line__", line)
        return node


def load_yaml_with_lines(file_path: Path) -> tuple[Dict[str, Any], Dict[str, int]]:
    """
    Load YAML file and track line numbers for error reporting.

    Returns:
        tuple: (data dict, line_map dict mapping paths to line numbers)
    """
    with open(file_path, "r") as f:
        yaml_content = f.read()
        loader = LineNumberLoader(yaml_content)
        data = loader.get_single_data()

    # Build a map of paths to line numbers
    line_map = {}

    def traverse(node, path=""):
        """Traverse YAML nodes and build line map."""
        if hasattr(node, "__line__"):
            line_map[path] = node.__line__

        if node.id == "mapping":
            # Dictionary node
            for key_node, value_node in node.value:
                key = key_node.value
                new_path = f"{path}.{key}" if path else key
                if hasattr(value_node, "__line__"):
                    line_map[new_path] = value_node.__line__
                traverse(value_node, new_path)
        elif node.id == "sequence":
            # List node
            for i, item_node in enumerate(node.value):
                new_path = f"{path}[{i}]"
                if hasattr(item_node, "__line__"):
                    line_map[new_path] = item_node.__line__
                traverse(item_node, new_path)

    # Parse again with line tracking
    with open(file_path, "r") as f:
        loader = LineNumberLoader(f)
        root_node = loader.get_single_node()
        traverse(root_node)

    return data, line_map


def _is_environment_url(string: str) -> bool:
    """Check if an environment path string is a valid URL using urlparse."""
    from urllib.parse import urlparse

    try:
        result = urlparse(string)
        return all([result.scheme, result.netloc])
    except ValueError:
        return False


# Validators
def validate_non_empty_string(v: str) -> str:
    """Validate that a string is not empty."""
    if not v or not v.strip():
        raise ValueError("must be a non-empty string")
    return v


def validate_non_empty_commit(v: str) -> str:
    """Validate commit hash is not empty."""
    if not v or not v.strip():
        raise ValueError("Commit must be a non-empty string")
    return v


def validate_hex_string(v: str) -> str:
    """Validate that a string is a valid hex string."""
    if not v:
        raise ValueError("must be a valid hexadecimal string")
    try:
        int(v, 16)
    except ValueError:
        raise ValueError("must be a valid hexadecimal string")
    return v


# Enums
class APIVersion(str, Enum):
    """API version enum."""

    V0_1_0 = "0.1.0"
    V0_2_0 = "0.2.0"
    V0_3_0 = "0.3.0"
    V0_4_0 = "0.4.0"
    V0_5_0 = "0.5.0"
    V0_6_0 = "0.6.0"
    V0_7_0 = "0.7.0"
    V0_8_0 = "0.8.0"

    @classmethod
    def latest(cls) -> "APIVersion":
        return cls.V0_8_0

    @classmethod
    def supported_versions(cls) -> set[str]:
        return {version.value for version in cls}

    # Version gates compare with <, <=, >=. Inherited from str those are
    # lexicographic, which would order "0.10.0" before "0.6.0"; order by parsed
    # components instead. (versioning.Version would do this too, but `model`
    # cannot import `versioning` — that package imports `model` back.)
    # Returning NotImplemented for a plain str would hand the comparison back
    # to str and reinstate the bug silently, so a non-member operand raises.
    @staticmethod
    def _parts(value: object) -> tuple[int, ...]:
        if not isinstance(value, APIVersion):
            raise TypeError(
                f"cannot order APIVersion against {type(value).__name__!r}: "
                f"{value!r} would compare lexicographically. Convert it with "
                "APIVersion(...) first."
            )
        return tuple(int(part) for part in value.value.split("."))

    def __lt__(self, other: object) -> bool:
        return self._parts(self) < self._parts(other)

    def __le__(self, other: object) -> bool:
        return self._parts(self) <= self._parts(other)

    def __gt__(self, other: object) -> bool:
        return self._parts(self) > self._parts(other)

    def __ge__(self, other: object) -> bool:
        return self._parts(self) >= self._parts(other)


# Labels the runtime populates on every node; a stage may not advertise these
# via `Stage.provides` (it would silently clobber the builtin value), and a
# gather may not `group_by` a stage named after one. See 008 §3.5.
#
# TODO(deprecate `dataset`): superseded by an explicit `Stage.provides` label on
# the data stage, which landed with 008 and says the same thing without being
# magic — `dataset` is implicit, inherited, and unavailable as a grouping axis
# (010 §6 Phase 2). Path: emit a deprecation warning when a spec relies on it,
# then drop it from this set at the next major api bump, which also frees
# `dataset` as an ordinary label and stage name. Until then it stays reserved.
_RESERVED_PROVIDES_LABELS = frozenset({"name", "dataset"})
# Stage and module ids (004 §3.13). The leading-digit rule is enforced for every
# id by IdentifiableEntity.
_ID_PATTERN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
# Output ids are free-form, except what would break `--output id=PATH`.
_BAD_OUTPUT_ID = re.compile(r"[=\s]")


class SoftwareBackendEnum(str, Enum):
    """Software backend types."""

    apptainer = "apptainer"
    conda = "conda"
    docker = "docker"
    envmodules = "envmodules"
    host = "host"


class RepositoryType(str, Enum):
    """Repository types."""

    git = "git"


# Storage API values still accepted for back-compat but no longer advertised
# (e.g. in the generated YAML reference template). Surfaced in the JSON schema as
# `deprecatedEnum` so tooling can distinguish them from supported values.
_DEPRECATED_STORAGE_APIS = frozenset({"MINIO"})


class StorageAPIEnum(str, Enum):
    """Storage API types. Currently only S3 is supported."""

    s3 = "S3"
    minio = "MINIO"  # Deprecated: MinIO is S3-compatible; use api: S3 with a custom endpoint.

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        json_schema = handler(core_schema)
        json_schema["deprecatedEnum"] = sorted(_DEPRECATED_STORAGE_APIS)
        return json_schema


# Base models
class IdentifiableEntity(BaseModel):
    """Base class for entities with an ID."""

    id: str = Field(..., description="Unique identifier")

    @field_validator("id")
    @classmethod
    def validate_id_not_starting_with_digit(cls, v: str) -> str:
        if v and v[0].isdigit():
            raise ValueError(
                f"id '{v}' must not start with a digit — "
                "Snakemake rule names are Python identifiers and cannot begin with a number"
            )
        return v


class DescribableEntity(IdentifiableEntity):
    """Base class for entities with ID, name, and description."""

    name: Optional[str] = Field(None, description="Human-readable name")
    description: Optional[str] = Field(None, description="Description of the entity")


class Repository(BaseModel):
    """Repository information."""

    url: str = Field(..., description="Repository URL")
    commit: str = Field(..., description="Commit hash")

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        return validate_non_empty_string(v)

    @field_validator("commit", mode="before")
    @classmethod
    def validate_commit(cls, v: Union[str, int, float]) -> str:
        # Convert numeric commit hashes to strings. Yes, they should not be numeric,
        # but we should handle it gracefully.
        v_str = str(v) if not isinstance(v, str) else v
        return validate_non_empty_commit(v_str)

    type: RepositoryType = Field(RepositoryType.git, description="Repository type")
    entrypoint: Optional[str] = Field(
        None,
        description="Named entrypoint key from the module's omnibenchmark.yaml. "
        "Defaults to 'default' when not specified.",
    )

    @field_validator("entrypoint")
    @classmethod
    def validate_entrypoint(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if not v.strip():
            raise ValueError("entrypoint must be a non-empty string if specified")
        return v


class Provenance(BaseModel):
    """Optional lineage metadata. No runtime effect; preserved for tooling."""

    canonical_url: Optional[str] = Field(
        None,
        description="Canonical URL where the authoritative version of this benchmark is published",
    )
    derived_from: Optional[str] = Field(
        None,
        description="Identifier or URL of the benchmark this one was forked/derived from",
    )
    subset_of: Optional[str] = Field(
        None,
        description="summary_hash() of the parent benchmark of which this is a subset",
    )


class Storage(BaseModel):
    """
    Storage configuration for remote storage of benchmark artifacts.
    This is intended for the benchmarker role, since they will have to
    provide the needed credentials to write in the store.
    """

    api: StorageAPIEnum = Field(
        StorageAPIEnum.s3,
        description="Storage API type (currently only S3 is supported)",
    )
    endpoint: str = Field(..., description="Storage endpoint URL")
    bucket_name: Optional[str] = Field(
        None, description="Storage bucket name (only needed if using S3)"
    )

    @field_validator("api", mode="after")
    @classmethod
    def warn_minio_deprecated(cls, v: "StorageAPIEnum") -> "StorageAPIEnum":
        if v == StorageAPIEnum.minio:
            import warnings

            warnings.warn(
                "Storage api 'MinIO' is deprecated. Use api: S3 with a custom endpoint instead.",
                DeprecationWarning,
                stacklevel=2,
            )
        return v


class Parameter(BaseModel):
    """Parameter definition - supports both CLI args format and key-value dict format.

    Two formats are supported:

    1. Legacy CLI args format (values):
       parameters:
         - values: ["--method", "cosine"]

    2. Key-value dict format (params):
       parameters:
         - method: genie
           threshold: 0.1
         - method: other
           k: [1, 2, 3]  # Expands to 3 runs with k=1, k=2, k=3

    IMPORTANT: In the dict format, any parameter value that is a list will trigger
    implicit Cartesian product expansion. Lists cannot be passed as literal values -
    they are always interpreted as grid expansion parameters.

    Example of Cartesian product:
       parameters:
         - alpha: [0.1, 0.5]  # 2 values
           beta: [1, 2, 3]    # 3 values
       # Expands to 6 parameter combinations: (0.1,1), (0.1,2), (0.1,3), (0.5,1), (0.5,2), (0.5,3)
    """

    id: str = Field(..., description="Parameter ID")
    values: Optional[List[str]] = Field(
        None, description="Parameter values as CLI args (legacy format)"
    )
    # NOTE: The 'params' field is an internal representation only. User should never
    # write 'params:' in YAML. When YAML like "method: genie" is parsed, the
    # @model_validator below automatically converts it to
    # params={"method": "genie"} internally.
    params: Optional[Dict[str, Any]] = Field(
        None,
        description="Parameter key-value pairs (supports lists for product expansion)",
    )

    @model_validator(mode="before")
    @classmethod
    def validate_parameter_format(cls, data: Any) -> Any:
        """Validate and normalize parameter format."""
        if isinstance(data, dict):
            has_values = "values" in data and data["values"] is not None
            has_params = "params" in data and data["params"] is not None

            # If neither is provided, check if data itself looks like a param dict
            if not has_values and not has_params:
                # Check if data has keys other than 'id'
                keys = set(data.keys()) - {"id"}
                if keys:
                    # Treat remaining keys as params
                    params_data = {k: data[k] for k in keys}
                    data["params"] = params_data
                    has_params = True

            if not has_values and not has_params:
                raise ValueError(
                    "Parameter must have either 'values' or parameter keys"
                )

            if has_values and has_params:
                raise ValueError(
                    "Parameter cannot have both 'values' and parameter keys"
                )

        return data

    @field_validator("values", mode="before")
    @classmethod
    def validate_values(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        if v is None:
            return None
        if not v:
            raise ValueError("Parameter values cannot be empty")
        # Convert all values to strings to handle mixed types (float, int, str)
        return [str(val) for val in v]

    @field_validator("params")
    @classmethod
    def validate_params(cls, v: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if v is not None and not v:
            raise ValueError("Parameter params cannot be empty")
        return v


class Validator(BaseModel):
    """A validator declared on a stage output (004 §3.14)."""

    script: str = Field(..., description="Validator script, relative to the plan")


class IOFile(IdentifiableEntity):
    """Input/Output file definition."""

    path: str = Field(..., description="File path")
    validators: List[Validator] = Field(
        default_factory=list,
        description="Validators run against this stage output (004 §3.14)",
    )

    @field_validator("path")
    @classmethod
    def validate_path(cls, v: str) -> str:
        return validate_non_empty_string(v)


class InputCollection(BaseModel):
    """Collection of input file IDs."""

    entries: List[str] = Field(..., description="List of input file IDs")


class GatherSpec(BaseModel):
    """A single fan-in: collect nodes producing a shared output id, grouped by
    a stage they descend from (design 010).

    `group_by` is a single **stage id** (not a tuple, not a label): members are
    partitioned by which node of that stage they descend from — structural
    grouping over the existing lineage chain, no `provides` labels needed.
    Omitting it collects every producer into one node, which is the shape a
    `metric_collector` has. `where` is deferred.
    """

    model_config = ConfigDict(populate_by_name=True)

    from_: str = Field(
        ...,
        alias="from",
        description="Output id to collect. Every node producing it is a member.",
    )
    group_by: Optional[str] = Field(
        None,
        description=(
            "Stage id to group members by. One gather node is created per "
            "distinct ancestor module of that stage among the members. A single "
            "stage id, not a list. Omit it for a global gather: every producer "
            "collected into one node, with no group segment in the output path."
        ),
    )


class Resources(BaseModel):
    """Resource requirements for Snakemake rules."""

    cores: Optional[int] = Field(None, description="Number of CPU cores", gt=0)
    mem_mb: Optional[int] = Field(None, description="Memory in megabytes", gt=0)
    disk_mb: Optional[int] = Field(None, description="Disk space in megabytes", gt=0)
    runtime: Optional[int] = Field(
        None, description="Expected runtime in minutes", gt=0
    )
    gpu: Optional[int] = Field(None, description="Number of GPUs", gt=0)

    @model_validator(mode="after")
    def validate_at_least_one_resource(self) -> "Resources":
        if not any([self.cores, self.mem_mb, self.disk_mb, self.runtime, self.gpu]):
            raise ValueError("At least one resource must be specified")
        return self


class SoftwareEnvironment(DescribableEntity):
    """Software environment configuration."""

    repository: Optional[Repository] = None
    conda: Optional[str] = Field(None, description="Conda environment file path")
    apptainer: Optional[str] = Field(
        None, description="Apptainer/Singularity image path"
    )
    docker: Optional[str] = Field(None, description="Docker image")
    envmodule: Optional[str] = Field(None, description="Environment module name")
    easyconfig: Optional[str] = Field(None, description="EasyBuild config path")

    @model_validator(mode="after")
    def validate_backend_config(self) -> "SoftwareEnvironment":
        """Ensure at least one backend configuration is provided."""
        # Temporarily disabled to allow benchmark-level validation
        # backends = [
        #     self.conda,
        #     self.apptainer,
        #     self.docker,
        #     self.envmodule,
        #     self.easyconfig,
        # ]
        # if not any(backends):
        #     raise ValueError(
        #         "At least one software backend must be configured (conda, apptainer, docker, envmodule, or easyconfig)"
        #     )
        return self


class ValidatorsConfig(BaseModel):
    """Configuration for output validators.

    Validators are declared on stage outputs (``outputs[].validators``). Each
    receives a single output file path and passes with exit code 0. All
    validators run in ``env``, or in the current environment when ``env`` is
    omitted.
    """

    env: Optional[str] = Field(
        None,
        description=(
            "software_environments id used to run all validators "
            "(default: the current environment)"
        ),
    )


class SoftwareEnvironmentReference(BaseModel):
    """Reference to a software environment."""

    software_environment: Optional[str] = Field(
        None,
        description=(
            "Software environment ID. May be omitted when exactly one "
            "software_environment is declared in the benchmark header; "
            "the sole environment is then used automatically."
        ),
    )


def _warn_if_disjoint_parameter_keys(
    parameters: Optional[List["Parameter"]],
    line_map: Optional[Dict[str, int]] = None,
) -> None:
    """Warn when parameter list items don't all share the same key set.

    The only safe pattern is items with identical key sets (a grid of values):
        - method: genie     <- same keys in every item
          threshold: 0.1
        - method: other
          threshold: 0.5

    Both fully-disjoint and partially-overlapping key sets are suspicious:
        Wrong (disjoint):           Wrong (partial overlap):
          - selection_type: [...]     - filter_type: [...]
          - number_selected: 2000     - filter_type: [...]
                                        this: ["a", "b"]
    """
    if parameters is None or len(parameters) < 2:
        return

    param_items = [p for p in parameters if p.params is not None]
    if len(param_items) < 2:
        return

    key_sets = [frozenset(p.params.keys()) for p in param_items if p.params is not None]

    if len(set(key_sets)) == 1:
        return

    per_item = [sorted(ks) for ks in key_sets]
    all_keys = sorted(set().union(*key_sets))

    line_hint = ""
    if line_map:
        for key in line_map:
            if "parameters[0]" in key:
                line_hint = f" (line {line_map[key]})"
                break

    YELLOW = "\033[33m"
    BOLD = "\033[1m"
    RESET = "\033[0m"
    indent = "      "
    sys.stderr.write(
        f"{BOLD}{YELLOW}WARN{RESET}{YELLOW}: parameter list has {len(param_items)} items "
        f"with inconsistent keys {per_item}{line_hint}.\n"
        f"{indent}Each item should have the same set of keys (a grid of values).\n"
        f"{indent}Did you mean to combine them under one item?\n"
        f"{indent}  Use:  - {' / '.join(all_keys)}: ...\n"
        f"{indent}  Instead of separate '- ' entries.{RESET}\n"
    )


def _warn_if_deprecated_dataset_var(path: str) -> None:
    """Warn when an output path still templates on the legacy ``{dataset}``.

    ``{dataset}`` resolves to the *first stage's* module id, which couples every
    downstream filename to it and degenerates to a constant as soon as the first
    stage is a single dispatcher module varying datasets by parameter. ``{module.id}``
    resolves to the current module's own id and has no such coupling.
    """
    if "{dataset}" not in path:
        return
    warnings.warn(
        f"Output path '{path}' uses the deprecated '{{dataset}}' template "
        f"variable. It resolves to the first stage's module id, so it is a "
        f"constant whenever that stage dispatches datasets by parameter. Prefer "
        f"'{{module.id}}' (this module's own id), or '{{params.KEY}}' to name "
        f"outputs after a parameter.",
        FutureWarning,
        stacklevel=3,
    )


class Module(DescribableEntity, SoftwareEnvironmentReference):
    """Module definition."""

    repository: Repository = Field(..., description="Module repository")
    software_environment: Optional[str] = Field(
        None, description="Software environment ID"
    )
    parameters: Optional[List[Parameter]] = Field(None, description="Module parameters")
    exclude: Optional[List[str]] = Field(
        None,
        description=(
            "Module IDs this module must not share an execution path with. "
            "Symmetric (declaring it on either module is equivalent), transitive "
            "(applies across non-adjacent stages), and OR over the list (a path "
            "is pruned if it contains this module together with any listed one). "
            "Non-module-id entries are silently ignored."
        ),
    )
    requires: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Lineage gate. Maps label name → required value: this module runs "
            "only on execution paths whose upstream lineage carries every "
            "label at exactly that value (string equality). Labels are "
            "advertised by a stage via `Stage.provides` and valued per node by "
            "`Module.provides`, defaulting to the producing module's id — so "
            "naming a module id here is the common case, not the contract. "
            "Downstream of a fan-in join the lineage is the union over every "
            "branch, so a gate may name a label carried by any of them; a "
            "gather cuts the chain and exposes only its group key. Non-matching "
            "paths prune at DAG-construction time. See docs/design/"
            "008-filtering.md §3.5."
        ),
    )
    provides: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Explicit benchmark-local label bindings for this module. Maps "
            "label name → value, for labels its stage advertises via "
            "`Stage.provides`. This is the recommended way to source a label "
            "value: it keeps routing out of the module's CLI parameter "
            "contract, so the same module stays reusable across benchmarks "
            "with different label vocabularies. When a label has no binding "
            "here, it defaults to the module id. Requires api_version ≥ 0.7.0."
        ),
    )
    resources: Optional[Resources] = Field(
        None,
        description="Resource requirements (overrides stage-level resources)",
    )
    requires_capabilities: Optional[List[str]] = Field(
        None,
        description=(
            "Host capabilities this module needs (e.g. gpu, large_mem). The "
            "module is pruned unless every listed capability is passed at run "
            "time via --with-capability. Host facts only — not lineage labels."
        ),
    )

    @field_validator("parameters")
    @classmethod
    def warn_disjoint_parameter_keys(
        cls, v: Optional[List[Parameter]], info
    ) -> Optional[List[Parameter]]:
        line_map = info.context.get("line_map") if info.context else None
        _warn_if_disjoint_parameter_keys(v, line_map)
        return v

    def has_environment_reference(self, env_id: Optional[str] = None) -> bool:
        """Check if module has a software environment reference."""
        if env_id is None:
            return bool(self.software_environment)
        return self.software_environment == env_id


class MetricCollector(DescribableEntity, SoftwareEnvironmentReference):
    """Metric collector definition."""

    repository: Repository = Field(..., description="Repository information")
    software_environment: Optional[str] = Field(
        None, description="Software environment ID"
    )
    inputs: List[Union[str, IOFile]] = Field(..., description="Input files")
    outputs: List[IOFile] = Field(..., description="Output files")
    parameters: Optional[List[Parameter]] = Field(
        None, description="Collector parameters"
    )
    resources: Optional[Resources] = Field(
        None, description="Resource requirements for this collector"
    )

    @field_validator("parameters")
    @classmethod
    def warn_disjoint_parameter_keys(
        cls, v: Optional[List[Parameter]], info
    ) -> Optional[List[Parameter]]:
        line_map = info.context.get("line_map") if info.context else None
        _warn_if_disjoint_parameter_keys(v, line_map)
        return v

    def has_environment_reference(self, env_id: Optional[str] = None) -> bool:
        """Check if metric collector has a software environment reference."""
        if env_id is None:
            return bool(self.software_environment)
        return self.software_environment == env_id


class Stage(DescribableEntity):
    """Stage definition."""

    modules: List[Module] = Field(..., description="Modules in this stage")
    inputs: Optional[List[InputCollection]] = Field(None, description="Stage inputs")
    outputs: List[IOFile] = Field(..., description="Stage outputs")
    provides: Optional[List[str]] = Field(
        None,
        description=(
            "Lineage labels this stage advertises to downstream modules. For "
            "each label, every node of this stage carries a value, taken from "
            "the module's `provides` binding if present, otherwise the module "
            "id. Downstream modules gate on these labels via `requires:`; "
            "non-matching execution paths prune at DAG-construction time. The "
            "builtin labels `name` and `dataset` are reserved and may not be "
            "declared here. Requires api_version ≥ 0.7.0."
        ),
    )
    resources: Optional[Resources] = Field(
        None, description="Resource requirements for rules in this stage"
    )
    gather: Optional[List[GatherSpec]] = Field(
        None,
        description=(
            "Fan-in specs (design 010). Each collects every node producing a "
            "shared output id, grouped by a stage they descend from. A gather "
            "cuts the lineage chain; its outputs root at the stage id. "
            "Requires api_version ≥ 0.7.0."
        ),
    )

    @model_validator(mode="after")
    def validate_gather(self) -> "Stage":
        if self.gather:
            # One axis per stage — including "no axis": mixing a grouped entry
            # with a global one has no meaning, so {None, "data"} is rejected
            # here just like {"data", "method"}.
            axes = {spec.group_by for spec in self.gather}
            if len(axes) > 1:
                shown = sorted(a or "<global>" for a in axes)
                raise ValueError(
                    f"Stage '{self.id}' has gather entries with differing "
                    f"group_by {shown}. A gather stage has one grouping "
                    f"axis; multiple axes are deferred (design 010 §3.3)."
                )
        return self

    @field_validator("outputs")
    @classmethod
    def validate_outputs(cls, v, info):
        """Reject duplicate output ids; warn about old-style full paths."""
        if not v:
            return v

        # Outputs are keyed by id downstream; a duplicate would drop silently.
        ids = [o.id for o in v]
        dupes = sorted({i for i in ids if ids.count(i) > 1})
        if dupes:
            raise ValueError(f"Duplicate output ids in stage: {dupes}")

        for idx, output in enumerate(v):
            if "/" in output.path:
                # Try to get line number from context
                line_info = ""
                if info.context and "line_map" in info.context:
                    line_map = info.context["line_map"]
                    # Search for this specific output path
                    search_pattern = f"outputs[{idx}].path"
                    for key in line_map:
                        if search_pattern in key and "stages[" in key:
                            line_info = f" (line {line_map[key]})"
                            break

                warnings.warn(
                    f"Output path '{output.path}' contains '/' {line_info}. "
                    "Full paths are deprecated. Use simple filenames without '/' like 'file.txt' instead.",
                    FutureWarning,
                    stacklevel=2,
                )

        return v

    @field_validator("inputs", mode="before")
    @classmethod
    def validate_inputs(cls, v, info):
        """Convert legacy string format to InputCollection."""
        if v is None:
            return v

        # Check if all items are strings (non-legacy format: a simple list of input IDs)
        # This should be treated as a single InputCollection with all items
        if all(isinstance(item, str) for item in v):
            return [InputCollection(entries=v)]

        result = []
        for idx, item in enumerate(v):
            # If it's a dict with 'entries' (legacy format with explicit entries field)
            if isinstance(item, dict) and "entries" in item:
                import warnings

                # Try to get line number from context
                line_info = ""
                if info.context and "line_map" in info.context:
                    line_map = info.context["line_map"]
                    # Search for any key containing inputs[idx].entries
                    # We don't know the stage index, so we search through all keys
                    search_pattern = f"inputs[{idx}].entries"
                    for key in line_map:
                        if search_pattern in key:
                            line_info = f" (line {line_map[key]})"
                            break

                warnings.warn(
                    f"Using 'entries' field in inputs is deprecated{line_info}. "
                    "Please use a simple list of strings instead: "
                    "inputs: ['data.matrix', 'data.true_labels'] instead of "
                    "inputs: [{entries: ['data.matrix', 'data.true_labels']}]. "
                    "Support for 'entries' will be removed in a future release.",
                    FutureWarning,
                    stacklevel=2,
                )
                result.append(item)
            # If it's already an InputCollection or other dict, keep as-is
            else:
                result.append(item)

        return result


class Benchmark(DescribableEntity, BenchmarkValidator):
    """Main benchmark definition."""

    @model_validator(mode="after")
    def set_authors_if_missing(self):
        # If authors is missing or empty, set it to [benchmarker]
        if not self.authors or len(self.authors) == 0:
            self.authors = [self.benchmarker]
        return self

    benchmarker: str = Field(..., description="Benchmark author")
    authors: Optional[List[str]] = Field(None, description="List of benchmark authors")
    version: str = Field(..., description="Benchmark version")
    software_backend: SoftwareBackendEnum = Field(..., description="Software backend")
    software_environments: List[SoftwareEnvironment] = Field(
        ..., description="Available software environments"
    )
    stages: List[Stage] = Field(..., description="Benchmark stages")
    metric_collectors: Optional[List[MetricCollector]] = Field(
        None, description="Metric collectors"
    )
    storage: Optional[Storage] = Field(None, description="Remote storage configuration")
    # Legacy Compatibility Fields - Migration Strategy
    # These fields maintain backward compatibility during the LinkML → Pydantic transition.
    # They're handled via property methods that delegate to the new structured fields.
    # Future consideration: Remove after confirming no external YAML files use these fields.
    storage_api: Optional[StorageAPIEnum] = Field(
        None, description="Storage API type (deprecated, use storage.api)"
    )
    storage_bucket_name: Optional[str] = Field(
        None, description="Storage bucket name (deprecated, use storage.bucket_name)"
    )
    benchmark_yaml_spec: Optional[Union[str, float, int]] = Field(
        None,
        description="Benchmark YAML specification version (deprecated, use api_version)",
    )
    api_version: APIVersion = Field(APIVersion.V0_4_0, description="API version")
    provenance: Optional[Provenance] = Field(None, description="Lineage metadata")
    validators: Optional[ValidatorsConfig] = Field(
        None, description="Output validators configuration"
    )

    @field_validator("api_version", mode="before")
    @classmethod
    def validate_api_version(cls, v: Union[str, APIVersion]) -> APIVersion:
        """Convert string API version to enum."""
        if isinstance(v, str):
            for version in APIVersion:
                if version.value == v:
                    return version
            # If no match found, raise ValueError
            raise ValueError(f"Invalid API version: {v}")
        return v

    @field_validator("version", mode="before")
    @classmethod
    def validate_version(cls, v: Union[str, int, float], info) -> str:
        """Validate that version follows strict semantic versioning format."""
        # Handle numeric types with deprecation warning
        if isinstance(v, (int, float)):
            # Try to get line number from context
            line_info = ""
            if info.context and "line_map" in info.context:
                line_map = info.context["line_map"]
                if "version" in line_map:
                    line_info = f" (line {line_map['version']})"

            warnings.warn(
                f"Field 'version' should be a string{line_info}. "
                f"Found {type(v).__name__} value: {v}. "
                f"This will not be valid in a future release. "
                f"Please update your YAML file to use a quoted string.",
                FutureWarning,
                stacklevel=4,
            )
            v = str(v)

        if not isinstance(v, str):
            raise ValueError("Version must be a string")

        if not v or not v.strip():
            raise ValueError("Version must be a non-empty string")

        v = v.strip()

        # Match semantic version pattern: x.y.z or x.y
        # No leading zeros allowed (except for "0" itself)
        pattern = r"^(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?$"
        if not re.match(pattern, v):
            raise ValueError(
                f"Version '{v}' does not follow strict semantic versioning format. "
                "Expected x.y.z or x.y where x, y, z are non-negative integers without leading zeros."
            )

        return v

    @field_validator("benchmark_yaml_spec", mode="before")
    @classmethod
    def validate_benchmark_yaml_spec(
        cls, v: Optional[Union[str, float, int]], info
    ) -> Optional[str]:
        """Validate benchmark_yaml_spec format if provided."""
        if v is None:
            return v

        if not isinstance(v, str):
            # Allow float/int for backwards compatibility but warn
            if isinstance(v, (float, int)):
                # Try to get line number from context
                line_info = ""
                if info.context and "line_map" in info.context:
                    line_map = info.context["line_map"]
                    if "benchmark_yaml_spec" in line_map:
                        line_info = f" (line {line_map['benchmark_yaml_spec']})"

                warnings.warn(
                    f"Field 'benchmark_yaml_spec' should be a string{line_info}. "
                    f"Found {type(v).__name__} value: {v}. "
                    f"This will not be valid in a future release. "
                    f"Please update your YAML file to use a quoted string.",
                    FutureWarning,
                    stacklevel=4,
                )
                return str(v)
            else:
                raise ValueError("benchmark_yaml_spec must be a string")

        return v

    # _benchmark_dir: Optional[Path] = None

    @classmethod
    def from_yaml(cls, path_or_content: Union[str, Path]) -> "Benchmark":
        """Load benchmark from YAML file or string content."""
        line_map = {}
        yaml_file_path = None

        if isinstance(path_or_content, (str, Path)) and "\n" not in str(
            path_or_content
        ):
            # Treat as file path
            yaml_file_path = Path(path_or_content)
            data, line_map = load_yaml_with_lines(yaml_file_path)
        else:
            # Treat as YAML content string
            data = yaml.safe_load(str(path_or_content))

        # An empty YAML document loads as None; every access below would then
        # die with a bare TypeError instead of pointing at the file (#391).
        if data is None:
            raise BenchmarkParseError(
                message=(
                    "The benchmark YAML contains no document. A benchmark "
                    "needs at least an id and a stages list."
                ),
                yaml_file=yaml_file_path,
                original_error=None,
            )

        # Convert dict-style software_environments to list format
        if "software_environments" in data and isinstance(
            data["software_environments"], dict
        ):
            envs: List[Dict[str, Any]] = []
            for env_id, env_config in data["software_environments"].items():
                env_dict = dict(env_config) if env_config else {}
                env_dict["id"] = env_id
                envs.append(env_dict)
            data["software_environments"] = envs

        # Generate parameter IDs for modules. These pre-walks reach the raw
        # YAML values before pydantic can reject them, so a null where a list
        # is expected must be caught here — otherwise it surfaces as a bare
        # "'NoneType' object is not iterable" with no hint of what to fix
        # (#391).
        if "stages" in data:
            if data["stages"] is None:
                raise BenchmarkParseError(
                    message=(
                        "'stages:' has no value (null). Set it to a list of "
                        "stages, e.g.\nstages:\n  - id: my_stage"
                    ),
                    yaml_file=yaml_file_path,
                    line_number=line_map.get("stages") if line_map else None,
                    original_error=None,
                )
            for stage_idx, stage in enumerate(data["stages"]):
                if stage is None:
                    raise BenchmarkParseError(
                        message=(
                            f"stages[{stage_idx}] has no value (null). Every "
                            "entry under 'stages:' must be a stage mapping."
                        ),
                        yaml_file=yaml_file_path,
                        line_number=line_map.get(f"stages[{stage_idx}]")
                        if line_map
                        else None,
                        original_error=None,
                    )
                if "modules" in stage:
                    if stage["modules"] is None:
                        stage_id = stage.get("id", f"<stage index {stage_idx}>")
                        raise BenchmarkParseError(
                            message=(
                                f"Stage '{stage_id}' has 'modules:' with no "
                                "value (null). Set it to a list of modules, "
                                "e.g.\nmodules:\n  - id: my_module"
                            ),
                            yaml_file=yaml_file_path,
                            line_number=line_map.get(f"stages[{stage_idx}].modules")
                            if line_map
                            else None,
                            stage_id=stage_id,
                            original_error=None,
                        )
                    for module_idx, module in enumerate(stage["modules"]):
                        if "parameters" in module and module["parameters"]:
                            for param_idx, param in enumerate(module["parameters"]):
                                # Emit deprecation warning for old 'values' format
                                if "values" in param:
                                    # Convert all parameter values to strings to handle mixed types (float, int, str)
                                    param["values"] = [str(v) for v in param["values"]]

                                    # Emit structured warning with line context
                                    from omnibenchmark.formatting import (
                                        format_yaml_warning,
                                    )
                                    from omnibenchmark.logging import logger

                                    stage_id = stage.get(
                                        "id", f"<stage index {stage_idx}>"
                                    )
                                    module_id = module.get(
                                        "id", f"<module index {module_idx}>"
                                    )

                                    # Find line number for this parameter
                                    param_line = None
                                    if line_map and yaml_file_path:
                                        possible_paths = [
                                            f"stages[{stage_idx}].modules[{module_idx}].parameters[{param_idx}].values",
                                            f"stages[{stage_idx}].modules[{module_idx}].parameters[{param_idx}]",
                                        ]
                                        for path in possible_paths:
                                            if path in line_map:
                                                param_line = line_map[path]
                                                break

                                    warning_msg = format_yaml_warning(
                                        message="Use dict format instead",
                                        yaml_file=yaml_file_path,
                                        line_number=param_line,
                                        stage_id=stage_id,
                                        module_id=module_id,
                                    )
                                    logger.warning(warning_msg)

                                if "id" not in param:
                                    # Generate a hash-based ID from the parameter
                                    import hashlib

                                    try:
                                        if "values" in param:
                                            # Legacy format: hash the values
                                            param_str = str(sorted(param["values"]))
                                        else:
                                            # New format: hash the entire param dict (excluding 'id')
                                            param_items = sorted(
                                                (k, v)
                                                for k, v in param.items()
                                                if k != "id"
                                            )
                                            param_str = str(param_items)

                                        param["id"] = hashlib.sha256(
                                            param_str.encode()
                                        ).hexdigest()[:8]
                                    except Exception as e:
                                        # Provide detailed error information
                                        stage_id = stage.get(
                                            "id", f"<stage index {stage_idx}>"
                                        )
                                        module_id = module.get(
                                            "id", f"<module index {module_idx}>"
                                        )

                                        # Try to find the line number in the YAML file
                                        line_num = None
                                        if line_map and yaml_file_path:
                                            # Try different path patterns to find the line
                                            possible_paths = [
                                                f"stages[{stage_idx}].modules[{module_idx}].parameters[{param_idx}]",
                                                f"stages[{stage_idx}].modules[{module_idx}].parameters[{param_idx}].values",
                                            ]
                                            for path in possible_paths:
                                                if path in line_map:
                                                    line_num = line_map[path]
                                                    break

                                        # Raise a BenchmarkParseError with all context information
                                        # The CLI layer will handle formatting
                                        raise BenchmarkParseError(
                                            message="Failed to process parameter values",
                                            yaml_file=yaml_file_path,
                                            line_number=line_num,
                                            stage_id=stage_id,
                                            module_id=module_id,
                                            parameter_index=param_idx,
                                            values=param.get("values"),
                                            original_error=e,
                                        ) from e

        # Convert string storage to Storage object and handle backward compatibility
        if "storage" in data:
            # Detect if using old format (top-level storage_api or storage_bucket_name)
            has_old_format_fields = (
                "storage_api" in data or "storage_bucket_name" in data
            )
            is_storage_dict = isinstance(data["storage"], dict)

            if isinstance(data["storage"], str):
                # Old format: storage: "https://endpoint.url"
                if not has_old_format_fields:
                    # Allow old format without storage_api/storage_bucket_name (use defaults)
                    pass
                storage_dict = {
                    "api": data.get("storage_api", "S3"),
                    "endpoint": data["storage"],
                }
                if "storage_bucket_name" in data:
                    storage_dict["bucket_name"] = data["storage_bucket_name"]
                data["storage"] = storage_dict
            elif is_storage_dict:
                # New format: storage: {endpoint, api, bucket_name}
                # Check for mixed format (both new dict and old top-level fields)
                if has_old_format_fields:
                    # Reject mixed format
                    line_num = None
                    if line_map and yaml_file_path:
                        # Try to find storage field line number
                        for path in ["storage", "storage_api", "storage_bucket_name"]:
                            if path in line_map:
                                line_num = line_map[path]
                                break

                    raise BenchmarkParseError(
                        message="Mixed storage format detected. Use either old format (storage: 'url', storage_api: 'S3', storage_bucket_name: 'name') OR new format (storage: {endpoint: 'url', api: 'S3', bucket_name: 'name'}), but not both.",
                        yaml_file=yaml_file_path,
                        line_number=line_num,
                        original_error=None,
                    )

        try:
            # Pass line_map through validation context for better error messages
            return cls.model_validate(data, context={"line_map": line_map})
        except PydanticValidationError as e:
            # Convert Pydantic validation error to BenchmarkParseError with context
            parse_error = convert_pydantic_error_to_parse_error(
                e, data, line_map, yaml_file_path
            )
            raise parse_error from e

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Benchmark":
        """Create benchmark from dictionary."""
        return cls(**data)

    def merge_with(self, other: "Benchmark") -> "Benchmark":
        """Merge this benchmark with another benchmark."""
        # Create a new benchmark with combined data
        merged_data = self.model_dump()
        other_data = other.model_dump()

        # Update with other's data (other takes precedence for scalar fields)
        for key, value in other_data.items():
            if key in ["stages", "metric_collectors", "software_environments"]:
                # For list fields, combine them
                if key == "stages":
                    existing_stages = {
                        stage["id"]: stage for stage in merged_data.get(key, [])
                    }
                    other_stages = {
                        stage["id"]: stage for stage in other_data.get(key, [])
                    }
                    existing_stages.update(other_stages)
                    merged_data[key] = list(existing_stages.values())
                elif key == "metric_collectors":
                    existing_collectors = {
                        mc["id"]: mc for mc in merged_data.get(key, [])
                    }
                    other_collectors = {mc["id"]: mc for mc in other_data.get(key, [])}
                    existing_collectors.update(other_collectors)
                    merged_data[key] = list(existing_collectors.values())
                elif key == "software_environments":
                    existing_envs = {env["id"]: env for env in merged_data.get(key, [])}
                    other_envs = {env["id"]: env for env in other_data.get(key, [])}
                    existing_envs.update(other_envs)
                    merged_data[key] = list(existing_envs.values())
            else:
                # For scalar fields, other takes precedence if not None
                if value is not None:
                    merged_data[key] = value

        return Benchmark(**merged_data)

    # Optional storage, with API compatibility
    # (Methods moved to StorageAccessors mixin)

    # API migration

    # TODO: are we using this?
    def upgrade_to_latest(self) -> "Benchmark":
        """Upgrade benchmark to latest API version."""
        # Check current version from either field
        current_version = getattr(self, "benchmark_yaml_spec", None) or str(
            self.api_version
        )
        latest_version = APIVersion.latest()

        if current_version == latest_version:
            return self

        # Create upgraded version
        data = self.model_dump()
        data["api_version"] = latest_version
        data["benchmark_yaml_spec"] = latest_version

        return Benchmark(**data)

    # Compatibility methods for LinkMLConverter interface
    # They can be removed when API migration is complete

    # TODO: deprecate if not in use.
    def get_storage_api(self) -> Optional[str]:
        """Get storage API with backward compatibility."""
        if self.storage and self.storage.api:
            return str(self.storage.api.value)
        return str(self.storage_api.value) if self.storage_api else None

    def get_storage_bucket_name(self) -> Optional[str]:
        """Get storage bucket name with backward compatibility."""
        if self.storage and self.storage.bucket_name:
            return self.storage.bucket_name
        return self.storage_bucket_name

    def get_storage_endpoint(self) -> Optional[str]:
        """Get storage endpoint."""
        if self.storage and self.storage.endpoint:
            return self.storage.endpoint
        return None

    def get_name(self) -> str:
        """Get name of the benchmark."""
        return self.name if self.name else self.id

    def get_version(self) -> str:
        """Get version of the benchmark."""
        return self.version

    def get_author(self) -> str:
        """Get author of the benchmark."""
        return self.benchmarker

    def summary_hash(self) -> str:
        """Stable SHA-256 hash of execution-relevant fields.

        Follows the same canonicalize-then-hash convention as Params: the
        fields that determine execution (id, software_backend,
        software_environments, stages, metric_collectors) are serialised to
        canonical JSON (sorted keys, sorted list elements where order is
        insignificant) and hashed with SHA-256.

        Excluded: benchmarker, authors, description, version (already part
        of the storage version string per design/003-storage.md), storage
        config, api_version, and provenance. Output ``validators`` are excluded
        too: they read outputs and never change them, so adding one must not
        change the hash (004 §3.14).

        Returns the full 64-character hex digest.  Use [:8] for the short
        form that matches the convention in Params.hash_short().
        """
        import json as _json
        import hashlib as _hashlib

        _EXEC_FIELDS = (
            "id",
            "software_backend",
            "software_environments",
            "stages",
            "metric_collectors",
        )
        _OMIT_ALWAYS = {
            "name",
            "description",
            "benchmarker",
            "authors",
            "version",
            "storage",
            "storage_api",
            "storage_bucket_name",
            "api_version",
            "benchmark_yaml_spec",
            "provenance",
        }

        raw = self.model_dump(mode="json")
        execution = {k: v for k, v in raw.items() if k in _EXEC_FIELDS}
        entities = (execution.get("stages") or []) + (
            execution.get("metric_collectors") or []
        )
        for entity in entities:
            for io in (entity.get("inputs") or []) + (entity.get("outputs") or []):
                if isinstance(io, dict):
                    io.pop("validators", None)
        canonical = _json.dumps(execution, sort_keys=True)
        return _hashlib.sha256(canonical.encode()).hexdigest()

    def get_software_backend(self) -> SoftwareBackendEnum:
        """Get software backend of the benchmark."""
        return self.software_backend

    def get_software_environments(self) -> Dict[str, SoftwareEnvironment]:
        """Get software environments as a dict."""
        return {env.id: env for env in self.software_environments}

    def get_validators_config(self) -> Optional["ValidatorsConfig"]:
        """Get the output validators configuration, if declared."""
        return self.validators

    def get_stages(self) -> Dict[str, Stage]:
        """Get benchmark stages as a dict."""
        return {stage.id: stage for stage in self.stages}

    def get_stage(self, stage_id: str) -> Optional[Stage]:
        """Get stage by stage_id."""
        stages = self.get_stages()
        return stages.get(stage_id)

    def get_stages_by_output(self, output_id: str) -> List[Stage]:
        """All stages declaring an output with output_id, in declaration order.

        Multiple stages may share an output id (the shared-output-id contract,
        design 010): a `gather.from` collects every producer. Returns every
        producing stage, deduped by stage id, declaration order preserved.
        Empty list if none produce it — the caller's "unknown output" signal.
        """
        seen: set = set()
        result: List[Stage] = []
        for stage in self.stages:
            if stage.id not in seen and any(o.id == output_id for o in stage.outputs):
                seen.add(stage.id)
                result.append(stage)
        return result

    def get_modules_by_stage(self, stage: Union[str, Stage]) -> Dict[str, Module]:
        """Get modules by stage/stage_id."""
        if isinstance(stage, str):
            stage_obj = self.get_stage(stage)
            if not stage_obj:
                return {}
            return {module.id: module for module in stage_obj.modules}
        return {module.id: module for module in stage.modules}

    def get_stage_implicit_inputs(self, stage: Union[str, Stage]) -> List[List[str]]:
        """Get implicit inputs of a stage by stage/stage_id.

        A gather stage consumes its `gather.from` output ids without declaring
        them under `inputs:` (design 010); they are included here as one extra
        entries group so every topology consumer (stage_adjacency → mermaid/
        dot/obeditor, the legacy DAGBuilder) sees the dependency.
        """
        if isinstance(stage, str):
            stage_obj = self.get_stage(stage)
            if stage_obj is None:
                return []
            stage = stage_obj
        groups = [input_col.entries for input_col in (stage.inputs or [])]
        gather_ids = [spec.from_ for spec in (stage.gather or [])]
        if gather_ids:
            groups.append(gather_ids)
        return groups

    def get_explicit_inputs(self, input_ids: List[str]) -> Dict[str, str]:
        """Get explicit inputs of a stage by input_id(s)."""
        all_stages_outputs: List[Dict[str, str]] = []
        for stage in self.stages:
            stage_outputs = self.get_stage_outputs(stage)
            # Resolve {stage} eagerly here; leave every other placeholder
            # ({input}, {module}, {params.*}, {dataset}, {name}, {module.*})
            # for the per-node template engine. We use str.replace rather than
            # str.format so dotted placeholders like {params.n_components}
            # pass through untouched instead of triggering attribute lookup.
            stage_outputs = {
                key: value.replace("{stage}", stage.id)
                for key, value in stage_outputs.items()
            }
            all_stages_outputs.append(stage_outputs)

        # Merge all stage outputs
        all_outputs = merge_dict_list(all_stages_outputs)

        result: Dict[str, str] = {}
        for input_id in input_ids:
            if input_id in all_outputs:
                result[input_id] = all_outputs[input_id]
            else:
                # Default to a placeholder
                result[input_id] = "{input_id}"

        return result

    def get_stage_outputs(self, stage: Union[str, Stage]) -> Dict[str, str]:
        """Get outputs of a stage by stage/stage_id."""
        if isinstance(stage, str):
            stage_obj = self.get_stage(stage)
            if not stage_obj:
                return {}
            stage = stage_obj

        flat = self.api_version >= APIVersion.V0_8_0  # 007 §3.1
        return {
            output.id: expand_output_path(output, flat=flat) for output in stage.outputs
        }

    def _resolve_module_attr(self, module: Union[str, Module], attr: str):
        """Resolve a module attribute by module/module_id."""
        module_obj = (
            module if isinstance(module, Module) else self.get_modules().get(module)
        )
        return getattr(module_obj, attr, None) if module_obj else None

    def get_module_excludes(self, module: Union[str, Module]) -> Optional[List[str]]:
        """Get module excludes by module/module_id."""
        match module:
            case str():
                module_obj = self.get_modules().get(module)
                if not module_obj or not module_obj.exclude:
                    return None
                return module_obj.exclude
            case Module():
                if not module.exclude:
                    return None
                return module.exclude

    def get_module_parameters(self, module: Union[str, Module]) -> Optional[List[Any]]:
        """Get module parameters by module/module_id."""
        module_obj = (
            module if isinstance(module, Module) else self.get_modules().get(module)
        )
        if not module_obj or not module_obj.parameters:
            return None

        result: List[Any] = []
        for p in module_obj.parameters:
            result.extend(Params.expand_from_parameter(p))

        return result

    def get_module_repository(self, module: Union[str, Module]) -> Optional[Repository]:
        """Get module repository by module/module_id."""
        return self._resolve_module_attr(module, "repository")

    def get_module_environment(self, module: Union[str, Module]) -> Optional[str]:
        """Get module software environment by module/module_id."""
        return self._resolve_module_attr(module, "software_environment")

    def get_metric_collectors(self) -> List[MetricCollector]:
        """Get metric collectors."""
        return self.metric_collectors or []

    def is_initial(self, stage: Stage) -> bool:
        """Whether a stage declares no `inputs:`. Legacy planner only.

        This conflates two questions that only coincide for a stage with no
        `gather:`. "Has no upstream producers" is `get_stage_implicit_inputs`,
        which folds in `gather.from` — a gather is not a root. "Roots its own
        output tree" is `node.parent_id is None` on the resolved node — a gather
        is. Callers wanting either should ask directly; this survives only for
        `core/_graph.py`, and goes away with it.
        """
        return stage.inputs is None or len(stage.inputs) == 0

    def get_outputs(self) -> Dict[str, IOFile]:
        """Get all outputs from all stages."""
        outputs: Dict[str, IOFile] = {}
        for stage in self.stages:
            for output in stage.outputs:
                outputs[output.id] = output
        return outputs

    def get_modules(self) -> Dict[str, Module]:
        """Get all modules from all stages."""
        modules: Dict[str, Module] = {}
        for stage in self.stages:
            for module in stage.modules:
                modules[module.id] = module
        return modules

    def get_easyconfigs(self) -> List[Optional[str]]:
        """Get easyconfigs from software environments."""
        return [env.easyconfig for env in self.software_environments]

    def get_conda_envs(self) -> List[Optional[str]]:
        """Get conda environment files from software environments."""
        return [env.conda for env in self.software_environments]

    # Validations

    @model_validator(mode="after")
    def validate_model_structure_post_init(self) -> "Benchmark":
        """Validate pure model structure after initialization (no execution context)."""
        # When exactly one software_environment is declared, auto-fill it for any
        # module / collector that did not specify one explicitly.
        if len(self.software_environments) == 1:
            sole_env_id = self.software_environments[0].id
            for stage in self.stages:
                for module in stage.modules:
                    if module.software_environment is None:
                        module.software_environment = sole_env_id
            if self.metric_collectors:
                for collector in self.metric_collectors:
                    if collector.software_environment is None:
                        collector.software_environment = sole_env_id

        # Gate api_version-introduced fields. `Stage.provides`, `Module.provides`
        # and `Stage.gather` were introduced in 0.7.0 and must not be used by
        # older specs.
        if self.api_version < APIVersion.V0_7_0:
            for stage in self.stages:
                if stage.provides:
                    raise ValueError(
                        f"Stage '{stage.id}' uses `provides`, which requires "
                        f"api_version ≥ 0.7.0 (this benchmark declares "
                        f"{self.api_version.value})."
                    )
                if stage.gather:
                    raise ValueError(
                        f"Stage '{stage.id}' uses `gather`, which requires "
                        f"api_version ≥ 0.7.0 (this benchmark declares "
                        f"{self.api_version.value})."
                    )
                for module in stage.modules:
                    if module.provides:
                        raise ValueError(
                            f"Module '{module.id}' uses `provides`, which "
                            f"requires api_version ≥ 0.7.0 (this benchmark "
                            f"declares {self.api_version.value})."
                        )

        for collector in self.metric_collectors or []:
            files = collector.outputs + [
                i for i in collector.inputs if isinstance(i, IOFile)
            ]
            if any(f.validators for f in files):
                raise ValueError(
                    f"Metric collector '{collector.id}' declares `validators`; "
                    f"validators apply to stage outputs only."
                )

        # Validators key by output id, which only named outputs (0.8.0) pin down.
        declares_validator = any(
            o.validators for stage in self.stages for o in stage.outputs
        )
        if (
            self.validators or declares_validator
        ) and self.api_version < APIVersion.V0_8_0:
            raise ValueError(
                f"`validators` requires api_version ≥ 0.8.0 (this benchmark "
                f"declares {self.api_version.value})."
            )

        # Node ids join stage and module ids with `-` and `.`; keeping those out
        # of the ids makes a node id parse back into its segments. Enforced from
        # 0.8.0, a warning before so existing plans keep loading. See 004 §3.13.
        for entity, kind in [(s, "Stage") for s in self.stages] + [
            (m, "Module") for s in self.stages for m in s.modules
        ]:
            if _ID_PATTERN.fullmatch(entity.id):
                continue
            msg = (
                f"{kind} id '{entity.id}' may only contain letters, digits "
                f"and underscores."
            )
            # Whitespace breaks the generated rules at every api version (#402).
            if self.api_version >= APIVersion.V0_8_0 or re.search(r"\s", entity.id):
                raise ValueError(msg)
            warnings.warn(
                f"{msg} This becomes an error at api_version 0.8.0.",
                FutureWarning,
                stacklevel=2,
            )

        # Output ids reach modules as `--output id=PATH` (009 §3.2) and as
        # `--<id>` input flags downstream, nowhere else, so only `=` and
        # whitespace are out.
        if self.api_version >= APIVersion.V0_8_0:
            collector_outputs = [
                o for c in self.metric_collectors or [] for o in c.outputs or []
            ]
            for o in [o for s in self.stages for o in s.outputs or []] + (
                collector_outputs
            ):
                if _BAD_OUTPUT_ID.search(o.id):
                    raise ValueError(
                        f"Output id '{o.id}' may not contain '=' or whitespace."
                    )

        # Below 0.5 `--name` is the dataset id, so downstream modules write
        # `{dataset}`-named files and the template is still the right one.
        if self.api_version >= APIVersion.V0_5_0:
            for stage in self.stages:
                for output in stage.outputs or []:
                    _warn_if_deprecated_dataset_var(output.path)

        # The runtime auto-populates `name` (current module id) and `dataset`
        # (root dataset identity) on every node; letting a stage advertise
        # either would silently clobber the user's value and make a downstream
        # `requires:` gate on an accident of propagation. See 008 §3.5.
        for stage in self.stages:
            for label in stage.provides or []:
                if label in _RESERVED_PROVIDES_LABELS:
                    raise ValueError(
                        f"Stage '{stage.id}' declares reserved label "
                        f"'{label}' in `provides`. '{label}' is a builtin "
                        f"populated by the runtime; choose another name."
                    )

        # A gather groups by a stage id and binds a label of that name to the
        # ancestor module id (010 §3.3), so stage ids and label names share one
        # namespace. A `provides` label named after a stage would carry that
        # stage's module id after the cut and the module's own binding before
        # it, and a downstream `requires:` would match on one side and prune
        # silently on the other. Keeping the two namespaces disjoint removes the
        # whole class instead of special-casing the gather. See 008 §3.5.
        stage_ids = {stage.id for stage in self.stages}
        for stage in self.stages:
            for label in stage.provides or []:
                if label in stage_ids:
                    raise ValueError(
                        f"Stage '{stage.id}' declares label '{label}' in "
                        f"`provides`, but '{label}' is also a stage id. "
                        f"Hint: rename the label."
                    )

        # A label names an axis, and one stage defines it. Two stages declaring
        # the same label leaves its value dependent on where you are standing:
        # on a chain the later stage silently overwrites the earlier, and on a
        # fan-in join the branches disagree with no non-arbitrary winner (the
        # "primary" branch is a topological accident, not something the author
        # can predict). Rejecting the declaration keeps the join's label union
        # well-defined and reports the problem where it was written. See 008
        # §3.5 "Label ownership".
        label_owner: Dict[str, str] = {}
        for stage in self.stages:
            for label in stage.provides or []:
                owner = label_owner.setdefault(label, stage.id)
                if owner != stage.id:
                    raise ValueError(
                        f"Stage '{stage.id}' declares label '{label}' in "
                        f"`provides`, but stage '{owner}' already declares it. "
                        f"A label is owned by exactly one stage; rename one of "
                        f"them."
                    )

        # A module can only bind a label its stage advertises. A `provides` key
        # absent from `stage.provides` is never consulted at resolution time
        # (`_resolve_label_value` iterates the stage's labels), so it would
        # silently fall through to the module_id default and break a downstream
        # `requires:` gate with no diagnostic. See 008 §2 (no silent absence).
        for stage in self.stages:
            declared = set(stage.provides or [])
            for module in stage.modules:
                for label in module.provides or {}:
                    if label not in declared:
                        raise ValueError(
                            f"Module '{module.id}' binds label '{label}' in "
                            f"`provides`, but stage '{stage.id}' does not "
                            f"declare it. Add '{label}' to the stage's "
                            f"`provides` list or fix the key."
                        )

        # A `requires:` gate matches against the upstream lineage, so it needs
        # one to match. Two stage shapes have none, for different reasons, and
        # each gets its own diagnostic. Read "has upstream producers" off
        # `get_stage_implicit_inputs`, which folds in `gather.from` — a gather
        # consumes real producers and is not a root. See 008 §2, 010 §3.3.
        for stage in self.stages:
            gated = next((m for m in stage.modules if m.requires), None)
            if gated is None:
                continue
            # A gather has upstream producers but cuts the chain, exposing only
            # its group key, and `expand_gather_stage` never evaluates
            # `requires` — accepting it would make the gate silently inert.
            # Gating on the group key itself is 010 Phase 2.
            if stage.gather:
                collected = ", ".join(f"'{spec.from_}'" for spec in stage.gather)
                raise ValueError(
                    f"Module '{gated.id}' in gather stage '{stage.id}' "
                    f"declares `requires`, but a gather collects members from "
                    f"many lineages at once, so there is no single lineage to "
                    f"match. Hint: move the `requires` to the modules "
                    f"producing {collected} — it will then decide which "
                    f"members get gathered."
                )
            if not self.get_stage_implicit_inputs(stage):
                raise ValueError(
                    f"Module '{gated.id}' in initial stage '{stage.id}' "
                    f"declares `requires`, but an initial stage has no "
                    f"upstream lineage to match against. Hint: remove the "
                    f"`requires` filter, or move the module to a later stage."
                )

        # A gather's `group_by` must name a real stage to partition members by,
        # and binding its id as a label must not clobber a runtime builtin.
        # Only the `group_by` target is constrained — a stage merely *called*
        # `dataset` is legal and stays legal in released 0.6 specs.
        for stage in self.stages:
            for spec in stage.gather or []:
                if spec.group_by is None:
                    continue
                if spec.group_by not in stage_ids:
                    raise ValueError(
                        f"Stage '{stage.id}' gathers with `group_by: "
                        f"{spec.group_by}`, which is not a known stage id."
                    )
                if spec.group_by in _RESERVED_PROVIDES_LABELS:
                    raise ValueError(
                        f"Stage '{stage.id}' gathers with `group_by: "
                        f"{spec.group_by}`, but '{spec.group_by}' is a "
                        f"reserved builtin label. Hint: rename the stage."
                    )

        # Call the pure model validation from the validator base class
        self.validate_model_structure()
        return self

    def validate_execution_context(self, benchmark_dir: Path) -> None:
        """Validate execution context including file paths and environment availability.

        ARCHITECTURAL WARNING: This method performs system-specific validation
        that violates the principle of keeping models abstract and declarative.

        TODO: Move this entire method to BenchmarkExecution class or a separate
        validation layer. The model should only validate data structure and
        logical consistency, not system state or file existence.
        """
        errors: List[str] = []

        # Fan-in (diamond) input joins are gated on api >= 0.7.0 (design 010
        # §5.2). Below 0.7.0 the resolver linearises each stage onto one lineage
        # and one branch silently falls out, so reject up front with an
        # actionable message. From 0.7.0 the join is resolved by
        # _select_input_bundles and the diamond is legal.
        if self.api_version < APIVersion.V0_7_0:
            errors.extend(self.detect_diamond_input_joins())

        errors.extend(self.detect_unsatisfiable_excludes())

        # Validate software environment paths (if benchmark_dir provided)
        if self.software_backend != SoftwareBackendEnum.host:
            for env in self.software_environments:
                env_errors = self._validate_environment_path(env, benchmark_dir)
                errors.extend(env_errors)

        # Raise error if any validation failed
        if errors:
            raise ValidationError(errors)

    def _validate_environment_path(
        self, env: SoftwareEnvironment, benchmark_dir: Path
    ) -> List[str]:
        """Validate software environment path based on backend.

        ARCHITECTURAL WARNING: This method performs system-specific validation
        that violates the principle of keeping models abstract and declarative.

        TODO: Move system-specific checks (file existence, envmodule availability)
        to BenchmarkExecution or a separate validation layer. The model should
        only validate data structure and logical consistency, not system state.
        """
        errors: List[str] = []

        # Get the appropriate environment configuration
        if self.software_backend == SoftwareBackendEnum.envmodules:
            # For envmodules, just check that the envmodule field is present
            # We don't try to load it during validation - that happens at runtime
            if not env.envmodule:
                errors.append(
                    f"Software environment with id '{env.id}' does not have a valid backend definition for: '{self.software_backend.value}'. The 'envmodule' field must be specified."
                )

        elif self.software_backend in [
            SoftwareBackendEnum.conda,
            SoftwareBackendEnum.docker,
            SoftwareBackendEnum.apptainer,
        ]:
            # Get the environment path based on backend
            env_path = None
            if self.software_backend == SoftwareBackendEnum.conda:
                env_path = env.conda
            elif self.software_backend in [
                SoftwareBackendEnum.docker,
                SoftwareBackendEnum.apptainer,
            ]:
                env_path = env.apptainer

            if not env_path:
                errors.append(
                    f"Software environment with id '{env.id}' does not have a valid backend definition for: '{self.software_backend.value}'."
                )
            elif not _is_environment_url(env_path) and not Path(env_path).is_absolute():
                # TODO: ARCHITECTURAL ISSUE - File system checks do not belong in abstract model
                # This should be moved to BenchmarkExecution or a separate validation layer
                # The model should only validate structure, not check file existence
                # Relative path - check relative to benchmark_dir
                full_path = benchmark_dir / env_path
                if not full_path.exists():
                    errors.append(
                        f"Software environment path for '{self.software_backend.value}' does not exist: '{full_path}'."
                    )
            elif not _is_environment_url(env_path) and Path(env_path).is_absolute():
                # TODO: ARCHITECTURAL ISSUE - File system checks do not belong in abstract model
                # This should be moved to BenchmarkExecution or a separate validation layer
                # The model should only validate structure, not check file existence
                # Absolute path - check directly
                if not Path(env_path).exists():
                    errors.append(
                        f"Software environment path for '{self.software_backend.value}' does not exist: '{env_path}'."
                    )

        return errors


def expand_output_path(file: IOFile, flat: bool = False) -> str:
    """
    Expands a relative output path into a standardized templated format.

    Prepends the standard OUTPUT_PATH_PREFIX if not already present. The
    filename is kept as written, as the run path does. ``flat`` selects the
    api 0.8.0 layout (007 §3.1); ``{params}`` carries its leading dot, so
    ``{stage}.{module}{params}`` is ``stage.module.<hash>``.
    """
    if flat:
        OUTPUT_PATH_PREFIX = os.path.join("{input}", "{stage}.{module}{params}")
    else:
        OUTPUT_PATH_PREFIX = os.path.join("{input}", "{stage}", "{module}", "{params}")

    output_path = file.path
    if output_path.strip() == "":
        raise ValueError(f"Output path for file {file.id} is empty")

    if os.path.isabs(output_path):
        raise ValueError(
            f"Output path for file {file.id} must be relative, not absolute: {output_path}"
        )

    if not output_path.startswith(OUTPUT_PATH_PREFIX):
        output_path = os.path.join(OUTPUT_PATH_PREFIX, output_path)

    return output_path


# For backwards compatibility
SoftwareEnvironmentId = str
