"""cli commands related to benchmark infos and stats"""

import logging
import sys
import time
import warnings
from typing import Any, List, Optional

import click
import json

from jinja2 import Environment, FileSystemLoader
from pathlib import Path

from omnibenchmark.core.status.status import prepare_status, print_exec_path_dict
from omnibenchmark.core.validators import load_verdicts, verdict_for
from omnibenchmark.core import BenchmarkExecution
from omnibenchmark.constants import STATUS_REPORT_FILE
from omnibenchmark.dag import get_node_attributes

from omnibenchmark.logging import logger
from .debug import add_debug_option


def _rows_to_html_table(
    columns: List[str],
    rows: List[List[Any]],
    table_id: str,
    classes: str,
) -> str:
    """Build an HTML table string from column names and row data."""
    th_cells = "".join(f"<th>{col}</th>" for col in columns)
    header = f'<tr style="text-align: right;">{th_cells}</tr>'
    body_rows = [
        "<tr>" + "".join(f"<td>{val}</td>" for val in row) + "</tr>" for row in rows
    ]
    body = "\n      ".join(body_rows)
    return (
        f'<table border="0" class="{classes}" id="{table_id}">\n'
        f"  <thead>\n    {header}\n  </thead>\n"
        f"  <tbody>\n    {body}\n  </tbody>\n"
        f"</table>"
    )


@click.group(name="describe")
@click.pass_context
def describe(ctx):
    """Describe benchmarks and/or information about them."""
    ctx.ensure_object(dict)


@add_debug_option
@describe.command("snakemake")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
@click.pass_context
def snakemake_graph(ctx, benchmark: str):
    """Export a snakemake computational graph to dot format.

    BENCHMARK: Path to benchmark YAML file.
    """
    b = BenchmarkExecution(benchmark_yaml=Path(benchmark))
    if b is None:
        return
    dot = b.export_to_dot()
    click.echo(dot.to_string())


@add_debug_option
@describe.command("topology")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
@click.option(
    "--show-params/--no-show-params",
    default=True,
    help="Whether to write parameters to the mermaid output.",
)
@click.option(
    "--compact-params/--no-compact-params",
    default=False,
    help="Whether to write parameters compactly (only used if --show-params).",
)
@click.pass_context
def plot_topology(ctx, benchmark, show_params, compact_params):
    """Export benchmark topology to MERMAID diagram format.

    BENCHMARK: Path to benchmark YAML file.
    """
    b = BenchmarkExecution(benchmark_yaml=Path(benchmark))
    if b is None:
        return
    mermaid = b.export_to_mermaid(show_params, compact_params)
    click.echo(mermaid)


def _render_text_status(
    benchmark,
    out_dir,
    show_missing_files: bool,
    show_incomplete_reason: bool,
    show_logs: bool,
) -> tuple[str, bool]:
    """Render the plain-text status report. Returns (report, is_complete)."""
    status_dict, _, exec_path_dict = prepare_status(
        benchmark, out_dir, return_all=True, cache_dir=Path(".snakemake") / "repos"
    )
    template_path = Path(__file__).parent.parent / "templates" / "status"
    env = Environment(loader=FileSystemLoader(template_path))
    stages = list(status_dict["stages"].keys())

    result_file_str = "\n".join(
        [
            f"  {f} {f'({s})' if s == 'missing' else ''}"
            for f, s in zip(
                status_dict["results"]["observed_output_files"]
                + status_dict["results"]["missing_output_files"],
                ["observed" for f in status_dict["results"]["observed_output_files"]]
                + ["missing" for f in status_dict["results"]["missing_output_files"]],
            )
        ]
    )

    max_str_len_stage = max([len(st) for st in stages])
    max_file_len = len(str(status_dict["total"]["n"]))
    is_complete = (
        status_dict["total"]["n_observed"] == status_dict["total"]["n"]
        and not status_dict["results"]["missing_output_files"]
    )

    template = env.get_template("cli_status.jinja")
    result_str = template.render(
        name=status_dict["name"],
        version=status_dict["version"],
        benchmark_structure=" -> ".join(
            [
                f"{st:>{max_str_len_stage}} ({status_dict['stages'][st]['n_modules']}, {status_dict['stages'][st]['n_nodes']})"
                for st in stages
            ]
        ),
        files_total_n_observed=status_dict["total"]["n_observed"],
        files_total_n=status_dict["total"]["n"],
        max_str_len_stage=max_str_len_stage,
        max_file_len=max_file_len,
        stages=stages,
        stage_stats={st: status_dict["stages"][st] for st in stages},
        exec_paths_block=print_exec_path_dict(
            exec_path_dict,
            stages,
            threshold_n_missing=1,
            full=show_incomplete_reason,
            logs=show_logs,
        ),
        result_file_str=result_file_str,
        show_incomplete_reason=show_incomplete_reason and not is_complete,
        show_missing_files=(show_missing_files or show_logs) and not is_complete,
    )
    return result_str, is_complete


@add_debug_option
@describe.command(
    name="status",
    context_settings=dict(
        ignore_unknown_options=False,
        allow_extra_args=False,
    ),
)
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
@click.option(
    "--out-dir", type=str, default="out", help="Output folder name (local only)."
)
@click.option(
    "--missing_files",
    "show_missing_files",
    is_flag=True,
    help="Show missing files in the status report.",
    default=False,
)
@click.option(
    "--reason",
    "show_incomplete_reason",
    is_flag=True,
    help="Show reason for missing files in the status report.",
    default=False,
)
@click.option(
    "--logs",
    "show_logs",
    is_flag=True,
    help="Show logs for missing files in the status report.",
    default=False,
)
@click.option(
    "--json",
    "return_json",
    is_flag=True,
    help="Return the status report as JSON.",
    default=False,
)
@click.option(
    "--html",
    "return_html",
    is_flag=True,
    help="Return the status report as HTML.",
    default=False,
)
@click.option(
    "--html-file",
    type=str,
    default=None,
    help="Output HTML path (default: <out-dir>/status_report.html).",
)
@click.option(
    "--force",
    "overwrite_html_file",
    is_flag=True,
    help="Overwrite an existing --html-file (the default report is always rewritten).",
    default=False,
)
@click.option(
    "--watch",
    default=None,
    metavar="SECONDS",
    type=click.FloatRange(min=0, min_open=True),
    help="Refresh the text report every SECONDS until all outputs exist.",
)
@click.pass_context
def status(
    ctx,
    benchmark,
    out_dir,
    show_missing_files: bool = False,
    show_incomplete_reason: bool = False,
    show_logs: bool = False,
    return_json: bool = False,
    return_html: bool = False,
    html_file: Optional[str] = None,
    overwrite_html_file: bool = False,
    watch: float | None = None,
):
    """Show the status of a benchmark.

    BENCHMARK: Path to benchmark YAML file.
    """
    ctx.ensure_object(dict)
    # Default the HTML report into the output folder. It is derived output, so
    # it is regenerated in place; only an explicit --html-file needs --force.
    if html_file is None:
        html_file = str(Path(out_dir) / STATUS_REPORT_FILE)
        overwrite_html_file = True
    if watch is not None and (return_json or return_html):
        raise click.UsageError("--watch only works with the text report.")
    if not return_json and not return_html:
        if watch is None:
            result_str, _ = _render_text_status(
                benchmark,
                out_dir,
                show_missing_files,
                show_incomplete_reason,
                show_logs,
            )
            logger.info(result_str)
            sys.exit(0)
        # Re-read the output tree on an interval; works for any executor
        # (local, SLURM, another terminal) since it only looks at files.
        try:
            while True:
                # Parse warnings would print above every redrawn frame.
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    logging.disable(logging.WARNING)
                    try:
                        result_str, is_complete = _render_text_status(
                            benchmark,
                            out_dir,
                            show_missing_files,
                            show_incomplete_reason,
                            show_logs,
                        )
                    finally:
                        logging.disable(logging.NOTSET)
                frame = result_str
                if not is_complete:
                    frame += f"\n\n(refreshing every {watch:g}s, Ctrl-C to stop)"
                if sys.stdout.isatty():
                    # Redraw in place in one write: clearing first flashes.
                    frame = "\033[H" + frame.replace("\n", "\033[K\n") + "\033[K\033[J"
                click.echo(frame)
                if is_complete:
                    sys.exit(0)
                time.sleep(watch)
        except KeyboardInterrupt:
            sys.exit(0)

    status_dict, filedict, exec_path_dict = prepare_status(
        benchmark, out_dir, return_all=True, cache_dir=Path(".snakemake") / "repos"
    )
    if return_json:
        logger.info(json.dumps(status_dict, indent=4))
        sys.exit(0)

    template_path = Path(__file__).parent.parent / "templates" / "status"
    env = Environment(loader=FileSystemLoader(template_path))
    stages = list(status_dict["stages"].keys())

    if return_html:
        # Load benchmark to get the graph
        b = BenchmarkExecution(Path(benchmark))
        G = b.G

        # Extract graph data for vis.js
        node_stages = get_node_attributes(G, "stage", default="unknown")

        # Collect log files and file status from exec_path_dict and filedict
        logs_by_node = {}
        files_by_node = {}
        status_by_node = {}

        for exec_path_id in exec_path_dict.keys():
            for st in exec_path_dict[exec_path_id].stages:
                eps = exec_path_dict[exec_path_id].exec_path[st]
                node_key = (st, eps.node.get_id())
                if node_key not in logs_by_node:
                    logs = []
                    if eps.log is not None:
                        logs.append(str(Path(eps.log).absolute()))
                    logs_by_node[node_key] = logs

        # Collect file status for each node
        for st in stages:
            for nd in filedict[st].keys():
                node_key = (st, nd.get_id())
                node_files = list(filedict[st][nd]["output_files"])
                files_by_node[node_key] = [str(Path(f).absolute()) for f in node_files]

                # Determine node status based on file validity
                if filedict[st][nd]["n_missing"] > 0:
                    status_by_node[node_key] = "missing"
                elif filedict[st][nd]["n_invalid"] > 0:
                    status_by_node[node_key] = "invalid"
                elif filedict[st][nd]["n_empty"] > 0:
                    status_by_node[node_key] = "empty"
                elif filedict[st][nd]["n_observed"] > 0:
                    status_by_node[node_key] = "complete"
                else:
                    status_by_node[node_key] = "unknown"

        # Output validation results (read-only; populated by `ob validate outputs`)
        validation_index = load_verdicts(Path(out_dir))

        def _node_validation(node_key):
            """Roll up per-output validation for a node -> (status, [log paths])."""
            statuses, vlogs = [], []
            for f in files_by_node.get(node_key, []):
                vstatus, vlog = verdict_for(f, validation_index)
                statuses.append(vstatus)
                if vstatus != "not_validated" and vlog:
                    vlogs.append(vlog)
            for worst in ("fail", "error", "stale", "pass"):
                if worst in statuses:
                    return worst, vlogs
            return "not_validated", vlogs

        # Define status colors (colorblind-friendly palette)
        status_color_dict = {
            "complete": "#999999",  # Grey
            "invalid": "#3200E6",  #
            "empty": "#F0E442",  # Yellow
            "missing": "#D50000",  #
            "unknown": "#222222",  # Dark Grey
        }

        # Validation colours — drawn as the node border (ring) so the file-status
        # fill stays visible underneath.
        validation_color_dict = {
            "pass": "#2ECC40",  # Green
            "fail": "#FF4136",  # Red
            "error": "#B10DC9",  # Purple: the validator could not run
            "stale": "#FF851B",  # Orange: output changed since validation
            "not_validated": "#cccccc",  # Light grey (thin ring)
        }

        # Create nodes data for vis.js
        graph_nodes = []
        for node in G.nodes:
            node_id = node.get_id()
            stage = node_stages.get(node, "unknown")
            node_key = (stage, node_id)

            # Get status and corresponding color
            status = status_by_node.get(node_key, "unknown")
            color = status_color_dict.get(status, "#cccccc")

            # Get files and logs for this node
            files = files_by_node.get(node_key, [])
            logs = logs_by_node.get(node_key, [])
            validation, validation_logs = _node_validation(node_key)
            validation_border = validation_color_dict.get(validation, "#cccccc")

            # Box label: stage / module (/ params, when not the default).
            label = f"{stage}\n{node.module_id}"
            if node.param_id.lstrip(".") != "default":
                label += f"\n{node.param_id}"

            graph_nodes.append(
                {
                    "id": node_id,
                    "label": label,
                    # File-status fill + validation ring (thick when validated).
                    "color": {"background": color, "border": validation_border},
                    "borderWidth": 1 if validation == "not_validated" else 4,
                    "stage": stage,
                    "module": node.module_id,
                    "status": status,
                    "files": files,
                    "logs": logs,
                    "validation": validation,
                    "validation_logs": validation_logs,
                    "title": f"Stage: {stage}\nModule: {node.module_id}\nParams: {node.param_id}\nStatus: {status}\nValidation: {validation}",
                }
            )

        # Create edges data for vis.js
        graph_edges = []
        for source, target in G.edges:
            graph_edges.append({"from": source.get_id(), "to": target.get_id()})

        # Create legend data for status
        graph_legend = [
            {"name": "Complete", "color": status_color_dict["complete"]},
            {"name": "Invalid", "color": status_color_dict["invalid"]},
            {"name": "Empty", "color": status_color_dict["empty"]},
            {"name": "Missing", "color": status_color_dict["missing"]},
            {"name": "Unknown", "color": status_color_dict["unknown"]},
        ]

        # Validation legend (node border / ring colours)
        validation_legend = [
            {"name": "Validated: pass", "color": validation_color_dict["pass"]},
            {"name": "Validated: fail", "color": validation_color_dict["fail"]},
            {"name": "Validator error", "color": validation_color_dict["error"]},
            {"name": "Stale verdict", "color": validation_color_dict["stale"]},
            {"name": "Not validated", "color": validation_color_dict["not_validated"]},
        ]

        # Collect files for table (keeping existing code)
        logs_by_node_str = {}
        for node_key, logs in logs_by_node.items():
            logs_by_node_str[node_key] = ", ".join(logs) if logs else ""

        all_files = []
        for st in stages:
            for nd in filedict[st].keys():
                node_key = (st, nd.get_id())
                logs_str = logs_by_node_str.get(node_key, "")
                all_files += [
                    [
                        str(Path(f).absolute()),
                        verdict_for(f, validation_index)[0],
                        f in filedict[st][nd]["observed_output_files"],
                        f in filedict[st][nd]["missing_output_files"],
                        f
                        in filedict[st][nd]["invalid_output_files_input_file_is_newer"],
                        f in filedict[st][nd]["invalid_output_files_repo_is_newer"],
                        nd.module_id,
                        nd.get_id(),
                        st,
                        logs_str,
                    ]
                    for j, f in enumerate(filedict[st][nd]["output_files"])
                ]
        all_columns = [
            "file",
            "validation",
            "observed",
            "missing",
            "stale: input changed",
            "stale: module changed",
            "module",
            "node",
            "stage",
            "logs",
        ]
        sum_columns = ["Stage", "Completed", "Missing", "Total", "Progress %"]
        sum_rows = [
            [
                st,
                status_dict["stages"][st]["n_observed"],
                status_dict["stages"][st]["n_missing"],
                status_dict["stages"][st]["n"],
                round(
                    status_dict["stages"][st]["n_observed"]
                    / status_dict["stages"][st]["n"]
                    * 100,
                    1,
                ),
            ]
            for st in stages
        ]

        # Build HTML tables
        all_table_html = _rows_to_html_table(
            all_columns, all_files, "all_table", "display"
        )
        sum_table_html = _rows_to_html_table(
            sum_columns, sum_rows, "status_table", "display"
        )

        # Add tfoot for column filters to the detailed table
        all_table_html = all_table_html.replace(
            "</table>",
            "<tfoot><tr>"
            + "".join([f"<th>{col}</th>" for col in all_columns])
            + "</tr></tfoot></table>",
        )

        template = env.get_template("cli_status.html.jinja")
        html = template.render(
            name=status_dict["name"],
            version=status_dict["version"],
            total_pct=round(
                status_dict["total"]["n_observed"] / status_dict["total"]["n"] * 100
            ),
            table1=sum_table_html,
            table2=all_table_html,
            graph_nodes=graph_nodes,
            graph_edges=graph_edges,
            graph_legend=graph_legend,
            validation_legend=validation_legend,
        )
        if Path(html_file).exists() and not overwrite_html_file:
            logger.error(
                f"HTML file {html_file} already exists. Use --force to overwrite."
            )
            sys.exit(1)
        # Save HTML to file
        with open(html_file, "w") as f:
            f.write(html)

        logger.info(f"HTML status report saved to {html_file}")
        sys.exit(0)
