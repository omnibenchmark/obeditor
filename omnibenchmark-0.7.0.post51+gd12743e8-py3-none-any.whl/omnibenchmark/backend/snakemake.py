"""
Explicit Snakefile generation from resolved nodes.

This module generates explicit, human-readable Snakefiles from ResolvedNode
entities. The generated Snakefiles use shell: directives with direct command
invocation, avoiding runtime complexity.

Design:
- Each ResolvedNode becomes one Snakemake rule
- Rules use shell: directive (not script:)
- Module paths are relative (.modules/{commit}/)
- Parameters are passed via CLI args
- No Python imports or omnibenchmark package dependency

The production generator is SnakemakeGenerator.  For dry-run/debug mode
see omnibenchmark.backend._snakemake_debug.DebugSnakemakeGenerator.
"""

import json
import os
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import shutil
import sys
from typing import List, Optional, TextIO

from omnibenchmark.core._paths import (
    _UNSAFE_CHARS,
    make_human_name as _make_human_name,
    sanitize_rule_name,
    truncate_filename,
)
from omnibenchmark.model.benchmark import APIVersion
from omnibenchmark.core._lineage import join_hash
from omnibenchmark.model.benchmark import SoftwareBackendEnum
from omnibenchmark.model.resolved import (
    ResolvedEnvironment,
    ResolvedModule,
    ResolvedNode,
)

# Snakemake flag that activates each backend's environment directive.
BACKEND_FLAGS = {
    SoftwareBackendEnum.conda: "--use-conda",
    SoftwareBackendEnum.apptainer: "--use-singularity",
    SoftwareBackendEnum.docker: "--use-singularity",
    SoftwareBackendEnum.envmodules: "--use-envmodules",
}


def snakemake_bin() -> str:
    """The snakemake next to the current Python (pixi/conda env), else PATH."""
    candidate = Path(sys.executable).parent / "snakemake"
    if candidate.exists():
        return str(candidate)
    return shutil.which("snakemake") or "snakemake"


def environment_directive(env: Optional[ResolvedEnvironment]) -> str:
    """The rule directive for a resolved environment; ``""`` for the host."""
    if env is None:
        return ""
    if env.backend_type.value == "conda":
        return f'conda: "{env.reference}"'
    if env.backend_type.value in ("apptainer", "docker"):
        return f'container: "{env.reference}"'
    if env.backend_type.value == "envmodules":
        return f'envmodules: "{env.reference}"'
    return ""


__all__ = [
    "BACKEND_FLAGS",
    "SnakemakeGenerator",
    "_UNSAFE_CHARS",
    "_make_human_name",
    "environment_directive",
    "snakemake_bin",
]

# Indentation constants for generated Snakemake syntax.
# Shell block content lives at 8 spaces (2 levels × 4 spaces).
_RULE_INDENT = "    "
_SHELL_INDENT = "        "


def _bash_var(name: str) -> str:
    """Turn an input flag name into a valid bash array variable name.

    >>> _bash_var("data.raw")
    '_data_raw'
    """
    return "_" + name.replace(".", "_").replace("-", "_")


# TODO: named input lists would delete this function and its callers.
#
# A gather node currently emits one rule key per member file:
#
#     input:
#         input_0="a/x.json",
#         input_1="b/x.json",
#     shell:
#         _data=(); for _f in {input.input_0} {input.input_1}; do ...
#
# and `input_name_mapping` exists only to remember that both keys belong to the
# `data` flag.  Emitting the group as a list instead:
#
#     input:
#         data=["a/x.json", "b/x.json"],
#     shell:
#         _data=(); for _f in {input.data}; do ...
#
# gives the same DAG (same file set) and one loop per flag regardless of member
# count.  Snakemake expands a named list in the order it was given, and that
# order is plan order -- the same order the lineage sidecar lists members in --
# so the enumerated keys, this sort, and `input_name_mapping` all go away for
# gather and collector nodes together.
#
# Nothing about the node surface moves: `ResolvedNode.inputs` keeps its
# `Dict[str, str]` shape and its `input_N` keys, so `to_dict()`, the telemetry
# spans that do `list(inputs.values())`, and node equality are unaffected.  The
# change is confined to the `input:` block in `_write_rule` and to both
# `_write_gather_shell` implementations.
#
# Blocked on one thing: the flag name becomes a Python keyword argument in the
# generated rule, so an id like `data.raw` is a syntax error and would need
# sanitizing plus a collision check.  That check is not worth writing -- we
# intend to forbid dots and other non-identifier characters in ids outright, at
# which point `from_id` is already a legal keyword and this is a mechanical
# swap.  Do it after #329, which is rewriting the same emission block.
def _input_key_index(key: str) -> int:
    """Sort key for the enumerated `input_N` keys of a gather/collector node.

    >>> sorted(["input_10", "input_2"], key=_input_key_index)
    ['input_2', 'input_10']
    """
    return int(key.rsplit("_", 1)[1])


def _human_link_name(node: ResolvedNode) -> str:
    """Name of the readable sibling symlink for a node's output directory.

    Parameters alone are not unique for a fan-in node: joins sharing a module
    and parameters differ only in their parents, so every one of them would
    claim the same link and `ln -sfn` would leave only whichever ran last.
    Suffix the parent-set digest — the same one the directory segment uses.
    """
    name = _make_human_name(node.parameters)
    parents = getattr(node, "parents", None) or []
    if len(parents) > 1:
        return f"{name}-{join_hash(parents)}"
    return name


class SnakemakeGenerator:
    """Generate explicit Snakefiles from resolved nodes (production mode).

    Each node becomes one Snakemake rule whose shell: block executes the
    module entrypoint directly.  Override _write_shell / _write_gather_shell
    to change the generated shell commands (see DebugSnakemakeGenerator).
    """

    def __init__(
        self,
        benchmark_name: str,
        benchmark_version: str,
        benchmark_author: str,
        api_version: APIVersion = APIVersion.V0_4_0,
    ):
        self.benchmark_name = benchmark_name
        self.benchmark_version = benchmark_version
        self.benchmark_author = benchmark_author
        self.api_version = api_version
        self._nodes_by_id: dict = {}

    def generate_snakefile(self, nodes: List[ResolvedNode], output_path: Path):
        """Write a complete Snakefile to *output_path*."""
        self._nodes_by_id = {n.id: n for n in nodes}
        with open(output_path, "w") as f:
            self._write_header(f)
            for node in nodes:
                self._write_node_rule(f, node)
            self._write_all_rule(f, nodes)

    # ------------------------------------------------------------------
    # Rule structure (shared between production and debug)
    # ------------------------------------------------------------------

    def _write_header(self, f: TextIO):
        """Write Snakefile header."""
        lines = [
            "#!/usr/bin/env snakemake",
            f"# OmniBenchmark: {self.benchmark_name} v{self.benchmark_version} ({self.benchmark_author})",
            f"# Generated: {datetime.now()}",
            "# Auto-generated — do not edit by hand.",
            "",
        ]
        f.write("\n".join(lines))

    def _write_node_rule(self, f: TextIO, node: ResolvedNode):
        """Write a complete rule block for one resolved node."""
        is_collector = node.is_collector
        is_gather = node.is_gather

        f.write(f"# Stage: {node.stage_id}, Module: {node.module_id}\n")
        if is_collector:
            f.write("# Type: Metric Collector\n")
        elif is_gather:
            f.write("# Type: Gather Stage\n")
        f.write(f"# Repository: {node.module.repository_url}\n")
        f.write(f"# Commit: {node.module.commit}\n")
        f.write(f"rule {self._sanitize_rule_name(node.id)}:\n")

        if node.inputs:
            f.write("    input:\n")
            for key, path in node.inputs.items():
                f.write(f'        {key}="{path}",\n')

        if node.outputs:
            # Positional at every api version: output ids never become Snakemake
            # names, so they need not be Python identifiers (009 §3.3).
            f.write("    output:\n")
            for path in node.outputs.values():
                f.write(f'        "{path}",\n')

        f.write("    params:\n")
        f.write(f'        module_dir="{node.module.module_dir}",\n')
        f.write(f'        entrypoint="{node.module.entrypoint}",\n')
        if node.outputs:
            f.write(
                '        output_dir=lambda wildcards, output: os.path.dirname(output[0]) or ".",\n'
            )
        if node.parameters:
            cli_args = " ".join(node.get_parameter_cli_args())
            f.write(f'        cli_args="{cli_args}",\n')
        else:
            f.write('        cli_args="",\n')

        # benchmark: directive (performance tracking, skipped for aggregate nodes)
        if not is_collector and not is_gather and node.outputs:
            first_output = next(iter(node.outputs.values()))
            benchmark_dir = (
                os.path.dirname(first_output) if "/" in first_output else "."
            )
            if self.api_version >= APIVersion.V0_5_0:
                benchmark_file = f"{benchmark_dir}/performance.txt"
            else:
                # COMPAT(0.4): collector R scripts scan for
                # "{dataset}_performance.txt".  parts[1] is the root module name.
                # Remove when 0.4 compat is dropped.
                parts = first_output.split("/")
                dataset_name = parts[1] if len(parts) > 2 else parts[0].split(".")[0]
                benchmark_file = f"{benchmark_dir}/{dataset_name}_performance.txt"
            f.write("    benchmark:\n")
            f.write(f'        "{benchmark_file}"\n')

        rule_name = self._sanitize_rule_name(node.id)
        log_filename = truncate_filename(f"{rule_name}.log")
        f.write("    log:\n")
        f.write(f'        ".logs/{log_filename}"\n')

        self._write_environment_directive(f, node.module)
        self._write_threads_directive(f, node)
        self._write_resources_directive(f, node)

        if is_collector or is_gather:
            self._write_gather_shell(f, node)
        else:
            self._write_shell(f, node)

        f.write("\n")

    def _write_all_rule(self, f: TextIO, nodes: List[ResolvedNode]):
        """Write the 'all' rule that depends on all node outputs."""
        f.write("# Target rule: executes entire benchmark\n")
        f.write("rule all:\n")
        f.write("    input:\n")
        for node in nodes:
            for output in node.outputs.values():
                f.write(f'        "{output}",\n')
        f.write("    default_target: True\n")
        f.write("\n")

    def _write_environment_directive(self, f: TextIO, resolved_module: ResolvedModule):
        """Write the appropriate Snakemake environment directive for a resolved module.

        Adds conda:, container:, or envmodules: based on the resolved environment.
        No-op for host backend or when no environment is specified.
        """
        directive = environment_directive(resolved_module.resolved_environment)
        if directive:
            f.write(f"    {directive}\n")

    def _write_threads_directive(self, f: TextIO, node: ResolvedNode):
        """Write Snakemake's threads: directive when a stage asks for cores.

        Distinct from the `cores` custom resource written below. Two things
        follow from threads: that the resource alone cannot give:

        * Snakemake exports OMP_NUM_THREADS=<threads> into every shell job, so
          BLAS/OpenMP libraries in the module actually get more than one
          thread. Left unset, threads is 1 and every module runs
          single-threaded no matter what the machine has.
        * The scheduler reserves that many of --cores for the job, instead of
          assuming 1 and oversubscribing the box.

        Only emitted when the stage declares resources.cores explicitly.
        Defaulting it would silently change scheduling for every existing
        benchmark, so opting in stays deliberate.
        """
        r = node.resources
        cores = r.cores if r is not None else None
        if cores:
            f.write(f"    threads: {cores}\n")

    def _write_resources_directive(self, f: TextIO, node: ResolvedNode):
        """Write Snakemake resources: directive for a node.

        Falls back to 2 cores when no resources are specified.
        """
        default_cores = 2
        f.write("    resources:\n")

        r = node.resources
        cores = (r.cores if r is not None else None) or default_cores
        f.write(f"        cores={cores}")

        if r is not None:
            if r.mem_mb:
                f.write(f",\n        mem_mb={r.mem_mb}")
            if r.disk_mb:
                f.write(f",\n        disk_mb={r.disk_mb}")
            if r.runtime:
                f.write(f",\n        runtime={r.runtime}")
            if r.gpu:
                f.write(f",\n        nvidia_gpu={r.gpu}")

        f.write("\n")

    def _sanitize_rule_name(self, node_id: str) -> str:
        """Sanitize node ID to a valid Snakemake rule name (Python identifier)."""
        return sanitize_rule_name(node_id)

    # ------------------------------------------------------------------
    # Shell writers — override in subclasses to change generated commands
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Fan-in provenance sidecar (design 010 §3.3/§5.2)
    # ------------------------------------------------------------------

    def _member_record(self, member_id: str) -> dict:
        """Enough to locate one contributing node without the run metadata."""
        member = self._nodes_by_id.get(member_id)
        if member is None:
            return {"node_id": member_id}
        return {
            "node_id": member.id,
            "stage": member.stage_id,
            "module": member.module_id,
            "commit": member.module.commit,
            "params": member.get_parameter_hash(),
            "dir": os.path.dirname(next(iter(member.outputs.values())))
            if member.outputs
            else None,
        }

    def _lineage_record(self, node: ResolvedNode):
        """Provenance record for a node whose path cannot encode its ancestry.

        A linear node needs none: its directory prefix *is* its lineage. A
        fan-in node (join or gather) has several parents and only one path
        prefix, so the other branches are recoverable from the filesystem only
        if written down. Returns None when the path already says it.
        """
        parents = list(getattr(node, "parents", None) or [])
        is_gather = bool(getattr(node, "is_gather", False))
        if not is_gather and len(parents) < 2:
            return None

        member_ids = list(getattr(node, "gathered_from", None) or []) or parents
        members = [self._member_record(member_id) for member_id in member_ids]
        return {
            "node_id": node.id,
            "stage": node.stage_id,
            "module": node.module_id,
            "kind": "gather" if is_gather else "join",
            "members": members,
        }

    def _lineage_sidecar_lines(self, node: ResolvedNode) -> list:
        """Shell lines writing lineage.json, or [] when the node needs none.

        Single-line echo, exactly as parameters.json is written: every line of
        a shell block is indented, and an indented heredoc terminator would not
        close the heredoc. Braces are doubled because Snakemake formats the
        block before bash sees it, and single quotes are escaped for the
        surrounding shell quoting.
        """
        record = self._lineage_record(node)
        if record is None:
            return []
        body = json.dumps(record)
        body = body.replace("{", "{{").replace("}", "}}")
        body = body.replace("'", "'\\''")
        return [f"echo '{body}' > $OUTPUT_DIR/lineage.json"]

    def _parameters_json_line(self, parameters) -> str:
        params_json = json.dumps(parameters._params)
        params_json_escaped = params_json.replace("{", "{{").replace("}", "}}")
        params_json_escaped = params_json_escaped.replace("'", "'\\''")
        return f"echo '{params_json_escaped}' > $OUTPUT_DIR/parameters.json"

    def _write_shell_lines(self, f: TextIO, lines: list) -> None:
        """Write a shell: block from a list of content lines.

        Handles the directive header, triple-quote delimiters, and uniform
        8-space indentation so callers only need to think about content.
        """
        f.write(f"{_RULE_INDENT}shell:\n")
        f.write(f'{_SHELL_INDENT}"""\n')
        for line in lines:
            f.write(f"{_SHELL_INDENT}{line}\n")
        f.write(f'{_SHELL_INDENT}"""\n')

    def _write_shell(self, f: TextIO, node: ResolvedNode):
        """Write the shell: block for a regular node (production execution).

        - Streams stdout/stderr through tee to both terminal and {log}
        - Writes parameters.json next to outputs
        - Uses pre-resolved shebang / interpreter info
        """
        lines: list = []

        # Resolve output and log directories to absolute paths before cd-ing
        # into the module directory.
        lines += [
            "mkdir -p {params.output_dir} $(dirname {log})",
            "OUTPUT_DIR=$(cd {params.output_dir} && pwd)",
        ]
        for key in node.inputs:
            lines.append(
                f"INPUT_{key}=$(cd $(dirname {{input.{key}}}) && pwd)"
                f"/$(basename {{input.{key}}})"
            )

        # Same for each declared output: the shell cds into the module directory
        # below, so a workflow-relative --output would land inside the module
        # checkout. Spec §3.2 promises absolute paths. Indexed by position, so
        # an output id never has to be a bash or Snakemake name.
        lines += self._output_file_lines(node)

        # Redirect stdout/stderr through tee so both the terminal and the log
        # file receive all output.
        lines += [
            "LOG_FILE=$(pwd)/{log}",
            'exec > >(tee "$LOG_FILE") 2>&1',
            "echo '=== Rule: {rule} ==='",
            "echo 'Started:' $(date -Iseconds)",
            "echo '---'",
        ]

        # Fan-in nodes: record the parents the path prefix cannot carry.
        lines += self._lineage_sidecar_lines(node)

        # Write parameters.json (and, before 0.8.0, a readable sibling link).
        if node.parameters:
            lines.append(self._parameters_json_line(node.parameters))
            # From 0.8.0 readable names live in the `human/` view (007 §3.1.2).
            if self.api_version < APIVersion.V0_8_0:
                # Link to the real directory name rather than re-deriving it:
                # a fan-in node's segment carries the parent-set digest as well
                # as the parameter hash, so recomputing it here would dangle.
                lines.append(
                    f'ln -sfn "$(basename $OUTPUT_DIR)"'
                    f" $OUTPUT_DIR/../{_human_link_name(node)}"
                )

        lines.append("cd {params.module_dir}")

        # Build command with backslash-continuations between parts.
        # --name is always the current module's own ID (spec §3.5 Reserved Parameters)
        # TODO: do not assume python3, only if .py maybe?
        if node.module.has_shebang:
            cmd = ["./{params.entrypoint}"]
        else:
            interpreter = node.module.interpreter or "python3"
            cmd = [f"{interpreter} {{params.entrypoint}}"]

        # Determine the value for --name parameter
        # BUG WORKAROUND (API <= 0.4): Legacy modules have a design flaw where they
        # use the --name parameter to construct output filenames ({name}_data.json),
        # but the benchmark spec expects outputs to be named after datasets
        # ({dataset}_data.json). This creates a mismatch when module_id != dataset_id.
        #
        # For API <= 0.4 ONLY, we work around this by passing the dataset name
        # (extracted from the output path structure) as --name instead of module_id.
        # This maintains backward compatibility with existing modules.
        #
        # For API >= 0.5, modules MUST use output_dir correctly and not depend on
        # --name for filename construction. Remove this workaround when 0.4 support ends.
        name_param = node.module_id
        if self.api_version <= APIVersion.V0_4_0 and node.outputs:
            first_output = next(iter(node.outputs.values()))
            parts = first_output.split("/")
            # Output path structure: data/{dataset}/.../[methods/{module}/...]/filename
            # We extract parts[1] which is the dataset identifier
            # Examples:
            #   data/D1/.94686c86/D1_data.json -> D1
            #   data/D1/.94686c86/methods/M1/.68f00a0d/D1_data.json -> D1
            if len(parts) > 1:
                dataset_name = parts[1]
                name_param = dataset_name

        cmd += ["--output_dir $OUTPUT_DIR", f"--name {name_param}"]

        cmd += self._output_flags(node)

        for key in node.inputs:
            original_name = node.input_name_mapping.get(key, key)
            cmd.append(f"--{original_name} $INPUT_{key}")
        if node.parameters:
            cmd.append("{params.cli_args}")

        for part in cmd[:-1]:
            lines.append(f"{part} \\\\")
        lines.append(cmd[-1])

        self._write_shell_lines(f, lines)

    def _output_file_lines(self, node: ResolvedNode) -> list:
        """From 0.8, absolutise each declared output into $OUTPUT_FILE_<i>.

        The shell cds into the module directory, so a workflow-relative
        --output would land inside the module checkout; spec 009 §3.2 promises
        absolute paths. Indexed by position, so an output id never has to be a
        bash or Snakemake name.
        """
        if self.api_version < APIVersion.V0_8_0:
            return []
        lines = []
        for i in range(len(node.outputs)):
            lines += [
                f"mkdir -p $(dirname {{output[{i}]}})",
                f"OUTPUT_FILE_{i}=$(cd $(dirname {{output[{i}]}}) && pwd)"
                f"/$(basename {{output[{i}]}})",
            ]
        return lines

    def _output_flags(self, node: ResolvedNode) -> list:
        """From 0.8, one `--output id=PATH` per declared output, for every kind
        of node (009 §3.2), however many outputs the stage declares."""
        if self.api_version < APIVersion.V0_8_0:
            return []
        return [
            f"--output {output_id}=$OUTPUT_FILE_{i}"
            for i, output_id in enumerate(node.outputs)
        ]

    def _write_gather_shell(self, f: TextIO, node: ResolvedNode):
        """Write the shell: block for a gather/collector node (production execution).

        Uses absolute paths for inputs and outputs so that collector scripts
        can safely call os.path.abspath() from any working directory.
        """
        inputs_by_name: defaultdict = defaultdict(list)
        if node.inputs and node.input_name_mapping:
            # Numeric, not lexicographic: keys are input_0..input_N and the
            # sidecar lineage lists members in plan order, so input_10 must not
            # sort between input_1 and input_2.
            for key in sorted(node.inputs.keys(), key=_input_key_index):
                original_name = node.input_name_mapping.get(key, key)
                inputs_by_name[original_name].append(key)

        lines: list = [
            "mkdir -p {params.output_dir}",
            "MODULE_DIR={params.module_dir}",
            "OUTPUT_DIR=$(cd {params.output_dir} && pwd)",
        ]

        # A gather cuts the chain, so its members exist nowhere in the path.
        lines += self._lineage_sidecar_lines(node)
        # `human/` and `ob collect` read parameter names from here. Nested
        # (pre-0.8.0) rules keep their text so existing trees do not rerun.
        if node.parameters and self.api_version >= APIVersion.V0_8_0:
            lines.append(self._parameters_json_line(node.parameters))
        lines += self._output_file_lines(node)

        # Resolve each input group to absolute paths into a bash array.
        # One loop per distinct flag name — no matter how many files per flag.
        for input_name, keys in inputs_by_name.items():
            var = _bash_var(input_name)
            refs = " ".join(f"{{input.{key}}}" for key in keys)
            lines += [
                f"{var}=()",
                f"for _f in {refs}; do",
                f'    {var}+=("$(cd $(dirname $_f) && pwd)/$(basename $_f)")',
                "done",
            ]

        # Build the multi-line command.  Continuation args are indented 4 extra
        # spaces relative to the entrypoint line so they visually align.
        if node.module.has_shebang:
            lines.append("$MODULE_DIR/{params.entrypoint} \\\\")
        else:
            interpreter = node.module.interpreter or "python3"
            lines.append(f"{interpreter} $MODULE_DIR/{{params.entrypoint}} \\\\")

        # Gather args: each on its own continuation line, 4 extra spaces.
        # Array expansion: ${{var[@]}} in the Snakefile so Snakemake unescapes {{ → {
        # and }} → } leaving bash with ${var[@]}.
        gather_args = ["--output_dir $OUTPUT_DIR", f"--name {node.module_id}"]
        gather_args += self._output_flags(node)
        for input_name in inputs_by_name:
            var = _bash_var(input_name)
            array_ref = '"${{' + var + '[@]}}"'
            gather_args.append(f"--{input_name} {array_ref}")
        if node.parameters:
            gather_args.append("{params.cli_args}")

        for arg in gather_args[:-1]:
            lines.append(f"    {arg} \\\\")
        lines.append(f"    {gather_args[-1]}")

        self._write_shell_lines(f, lines)
