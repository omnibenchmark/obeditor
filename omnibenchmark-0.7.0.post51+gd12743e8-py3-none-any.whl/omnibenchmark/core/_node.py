import os.path
from pathlib import Path
from typing import Optional

from omnibenchmark.core._paths import substitute_node_vars
from omnibenchmark.model import SoftwareBackendEnum


class BenchmarkNode:
    def __init__(
        self,
        model,
        stage,
        module,
        parameters,
        inputs,
        outputs,
        after=None,
    ):
        self.model = model
        self.stage = stage
        self.module = module
        self.parameters = parameters
        self.inputs = inputs
        self.outputs = outputs
        self.after = after

        self.stage_id = stage.id
        self.module_id = module.id
        self.param_id = (
            ".default" if not self.parameters else f".{self.parameters.hash_short()}"
        )

    def is_entrypoint(self):
        return not self.inputs or len(self.inputs) == 0

    def get_id(self):
        return BenchmarkNode.to_id(
            self.stage_id, self.module_id, self.param_id, self.after
        )

    def get_benchmark_name(self):
        return self.model.get_name()

    def get_benchmark_version(self):
        return self.model.get_version()

    def get_benchmark_author(self):
        return self.model.get_author()

    def get_benchmark_software_backend(self):
        return self.model.get_software_backend()

    def get_benchmark_software_environments(self):
        return self.model.get_software_environments()

    def get_definition(self):
        return self.model

    def get_inputs(self):
        return self.inputs.values() if self.inputs else []

    def get_inputs_dict(self):
        return self.inputs if self.inputs else {}

    def get_explicit_inputs(self):
        explicit_inputs = [
            self.model.get_explicit_inputs(i)
            for i in self.model.get_stage_implicit_inputs(self.stage)
        ]
        return explicit_inputs

    def get_input_paths(self, config, return_as_dict=False):
        input_paths = {}
        inputs = self.inputs.items() if self.inputs else {}
        for key, input in inputs:
            input = os.path.basename(input)
            input = input.replace("{dataset}", config["dataset"])
            input = os.path.join(config["input"], input)
            input_paths[key] = input

        if return_as_dict:
            return input_paths
        else:
            return list(input_paths.values())

    def get_outputs(self):
        """Return outputs as dict {id: path_template}."""
        return self.outputs if self.outputs else {}

    def get_output_paths(self, config):
        pre = config.get("input", config.get("output"))
        dataset = config["dataset"]
        output_paths = []
        for path in self.get_outputs().values():
            path = substitute_node_vars(path, self, pre)
            output_paths.append(
                path.replace("{pre}", str(pre)).replace("{dataset}", dataset)
            )
        return output_paths

    def get_parameters(self):
        return self.parameters

    def get_repository(self):
        return self.model.get_module_repository(module=self.module)

    def get_software_environment(self):
        return self.model.get_module_environment(module=self.module)

    def is_initial(self):
        return self.model.is_initial(self.stage)

    def get_stage(self):
        return self.stage

    def display_name(self):
        return BenchmarkNode.to_id(
            self.stage_id, self.module_id, self.param_id, self.after
        )

    def get_environment_path(
        self, env_key: str, software_backend: SoftwareBackendEnum, benchmark_dir: Path
    ) -> Optional[str]:
        from omnibenchmark.core import Validator

        environment = self.get_benchmark_software_environments().get(env_key, None)
        environment_path = (
            Validator.get_environment_path(software_backend, environment, benchmark_dir)
            if environment
            else None
        )

        return environment_path

    def __str__(self):
        return self.display_name()

    def __repr__(self):
        return str(self)

    def __eq__(self, other):
        if isinstance(other, BenchmarkNode):
            return (self.stage_id, self.module_id, self.parameters, self.inputs) == (
                other.stage_id,
                other.module_id,
                other.parameters,
                other.inputs,
            )
        return False

    def __hash__(self):
        return hash(self.get_id())

    @staticmethod
    def to_id(stage_id, module_id, param_id, after_stage_id=None):
        node_id = f"{stage_id}-{module_id}-{param_id}"
        node_id += f"-after_{after_stage_id}" if after_stage_id else ""

        return node_id
